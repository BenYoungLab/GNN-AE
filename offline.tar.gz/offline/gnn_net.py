import dgl
import torch
import torch.nn as nn
from dgl.nn.pytorch.glob import SumPooling, AvgPooling, MaxPooling
from gnn_layer import GATLayer, GINLayer, ApplyNodeFunc, MLP, MLPReadout


class GATNet(nn.Module):
    def __init__(self, net_params):
        super().__init__()
        node_label_types = net_params['node_label_types']
        hidden_dim = net_params['hidden_dim']
        num_heads = net_params['n_heads']
        out_dim = net_params['out_dim']
        in_feat_dropout = net_params['in_feat_dropout']
        dropout = net_params['dropout']
        n_layers = net_params['L']
        emb_dimension = net_params['emb_dimension']
        self.readout = net_params['readout']
        self.batch_norm = net_params['batch_norm']
        self.residual = net_params['residual']

        self.dropout = dropout

        self.embedding_h = nn.Embedding(node_label_types, hidden_dim * num_heads)
        self.in_feat_dropout = nn.Dropout(in_feat_dropout)

        self.layers = nn.ModuleList([GATLayer(hidden_dim * num_heads, hidden_dim, num_heads,
                                              dropout, self.batch_norm, self.residual) for _ in range(n_layers - 1)])
        self.layers.append(GATLayer(hidden_dim * num_heads, out_dim, 1,
                                    dropout, self.batch_norm, self.residual))
        self.MLP_layer = MLPReadout(out_dim, emb_dimension)
        self.scoring_layer = torch.nn.Linear(emb_dimension, 1)  # 1 out dim since regression problem

    def forward(self, g, h):
        h = self.embedding_h(h)
        h = self.in_feat_dropout(h)
        for con_v in self.layers:
            h = con_v(g, h)
        g.ndata['h'] = h

        if self.readout == "sum":
            hg = dgl.sum_nodes(g, 'h')
        elif self.readout == "max":
            hg = dgl.max_nodes(g, 'h')
        elif self.readout == "mean":
            hg = dgl.mean_nodes(g, 'h')
        else:
            hg = dgl.mean_nodes(g, 'h')  

        score_over_layer = self.MLP_layer(hg)
        score = self.scoring_layer(score_over_layer)

        return score, score_over_layer

    def loss(self, scores, targets):
        # loss = nn.MSELoss()(scores,targets)
        loss = nn.L1Loss()(scores, targets)
        return loss


class GINNet(nn.Module):
    def __init__(self, net_params):
        super().__init__()
        node_label_types = net_params['node_label_types']
        hidden_dim = net_params['hidden_dim']
        dropout = net_params['dropout']
        self.n_layers = net_params['L']
        n_mlp_layers = net_params['n_mlp_GIN']
        learn_eps = net_params['learn_eps_GIN']
        neighbor_aggr_type = net_params['neighbor_aggr_GIN']
        readout = net_params['readout']
        batch_norm = net_params['batch_norm']
        residual = net_params['residual']
        emb_dimension = net_params['emb_dimension']

        self.gin_layers = torch.nn.ModuleList()

        self.embedding_h = nn.Embedding(node_label_types, hidden_dim)

        for layer in range(self.n_layers):
            mlp = MLP(n_mlp_layers, hidden_dim, hidden_dim, hidden_dim)

            self.gin_layers.append(GINLayer(ApplyNodeFunc(mlp), neighbor_aggr_type,
                                            dropout, batch_norm, residual, 0, learn_eps))

        self.linear_prediction = torch.nn.ModuleList()

        for layer in range(self.n_layers + 1):
            self.linear_prediction.append(nn.Linear(hidden_dim, emb_dimension))

        self.scoring_layer = torch.nn.Linear(emb_dimension, 1)  # 1 out dim since regression problem

        if readout == 'sum':
            self.pool = SumPooling()
        elif readout == 'mean':
            self.pool = AvgPooling()
        elif readout == 'max':
            self.pool = MaxPooling()
        else:
            raise NotImplementedError

    def forward(self, g, h):

        h = self.embedding_h(h)

        hidden_rep = [h]

        for i in range(self.n_layers):
            h = self.gin_layers[i](g, h)
            hidden_rep.append(h)

        score_over_layer = 0

        for i, h in enumerate(hidden_rep):
            pooled_h = self.pool(g, h)
            score_over_layer += self.linear_prediction[i](pooled_h)

        score = self.scoring_layer(score_over_layer)

        return score, score_over_layer

    def loss(self, scores, targets):
        # loss = nn.MSELoss()(scores,targets)
        loss = nn.L1Loss()(scores, targets)
        return loss


def gnn_model(MODEL_NAME, net_params):
    models = {'GAT': GATNet, 'GIN': GINNet}

    return models[MODEL_NAME](net_params)
