

def statistics_sparse_ags(sparse_ags_no_emb):
    count_ag = 0
    for key in sparse_ags_no_emb:
        count_ag = count_ag + len(sparse_ags_no_emb[key])

    return count_ag


def statistics_item_sparse(sparse_index):
    epsilon = 1e-10
    p_count_match, p_count_item = 0, 0
    for key in sparse_index:
        p_aes = sparse_index[key]['p_aes']
        for p_string in p_aes:
            p_ae_matching = p_aes[p_string]['ae_matching']
            for anchor_end_node in p_ae_matching:
                p_count_match = p_count_match + len(p_ae_matching[anchor_end_node])
            p_count_item = p_count_item + 1
    p_avg_item_match = int(p_count_match / (p_count_item + epsilon))

    n_count_match, n_count_item = 0, 0
    for key in sparse_index:
        n_aes = sparse_index[key]['n_aes']
        for n_string in n_aes:
            n_ae_matching = n_aes[n_string]['ae_matching']
            for anchor_end_node in n_ae_matching:
                n_count_match = n_count_match + len(n_ae_matching[anchor_end_node])
            n_count_item = n_count_item + 1
    n_avg_item_match = int(n_count_match / (n_count_item + epsilon))

    return p_avg_item_match, n_avg_item_match


def statistics_item_dd(dd_index):
    epsilon = 1e-10
    dd_count_match, dd_count_item = 0, 0
    for key in dd_index:
        dd_entry = dd_index[key]
        for anchor_end_node in dd_entry:
            dd_count_match = dd_count_match + len(dd_entry[anchor_end_node])
        dd_count_item = dd_count_item + 1
    dd_avg_item_match = int(dd_count_match / (dd_count_item + epsilon))

    return dd_avg_item_match


def output_dd_files(file_dd, dd_index):
    with open(file_dd, "w") as output:
        path_emb_id = 0
        for path_emb in dd_index:
            output.write('t ' + str(path_emb_id) + '\n')
            output.write('path_emb ' + path_emb + '\n')
            for anchor_end_node in dd_index[path_emb]:
                output.write('m ' + str(anchor_end_node))
                for node in dd_index[path_emb][anchor_end_node]:
                    output.write(' ' + str(node))
                output.write('\n')
            path_emb_id += 1
    output.close()


def output_index_files(index_file, index):
    # sparse index format: {string(1.23-4.25): {'sparse_ag_emb': [1.23, 4.25],
    # 'p_aes': {string(34-45): {'ae_labels': [34, 45], 'ae_matching': {v1: {v6, v2}, v2: {v1}}}, ...},
    # 'n_aes': {string(45-34): {'ae_labels': [45, 34], 'ae_matching': {v1: {v6, v9}, v4: {v3}}}, ...}}
    with open(index_file, "w") as output:
        entry_id = 0
        for sparse_string in index:
            output.write('t ' + str(entry_id) + '\n')
            entry_id = entry_id + 1

            sparse_ag_emb = index[sparse_string]['sparse_ag_emb']
            output.write('sparse_ag_emb')
            for i in range(len(sparse_ag_emb)):
                output.write(' ' + str(sparse_ag_emb[i]))
            output.write('\n')

            p_aes = index[sparse_string]['p_aes']
            for ae_string in p_aes:
                p_ae = p_aes[ae_string]
                p_ae_labels = p_ae['ae_labels']
                output.write('p_ae_labels ' + str(p_ae_labels[0]) + ' ' + str(p_ae_labels[1]) + '\n')
                p_ae_matching = p_ae['ae_matching']
                for anchor_end_node in p_ae_matching:
                    output.write('p_m ' + str(anchor_end_node))
                    for anchor_node in p_ae_matching[anchor_end_node]:
                        output.write(' ' + str(anchor_node))
                    output.write('\n')

            n_aes = index[sparse_string]['n_aes']
            if len(n_aes) > 0:
                for ae_string in n_aes:
                    n_ae = n_aes[ae_string]
                    n_ae_labels = n_ae['ae_labels']
                    output.write('n_ae_labels ' + str(n_ae_labels[0]) + ' ' + str(n_ae_labels[1]) + '\n')
                    n_ae_matching = n_ae['ae_matching']
                    for anchor_end_node in n_ae_matching:
                        output.write('n_m ' + str(anchor_end_node))
                        for anchor_node in n_ae_matching[anchor_end_node]:
                            output.write(' ' + str(anchor_node))
                        output.write('\n')


def output_ag_emb(file, emb_name, emb):
    file.write(emb_name)
    for i in range(len(emb)):
        file.write(' ' + str(emb[i]))
    file.write('\n')


def output_query_emb_file(query_out_path, queries, dd_path_threshold):
    for key in queries:
        with open(query_out_path + key, "w") as output:
            for dfs_edge in queries[key]['dfs_edges']:
                dfs_edge_key = str(dfs_edge[0]) + '-' + str(dfs_edge[1])
                structures = queries[key]['anchor_structures'][dfs_edge_key]
                output.write('dfs_edge ' + dfs_edge_key + '\n')
                ae_labels = structures['p_anchor_graph']['ae_labels']
                output.write('dfs_edge_labels ' + str(ae_labels[0]) + ' ' + str(ae_labels[1]) + '\n')
                if 'p_anchor_graph_emb' in structures:
                    output_ag_emb(output, 'p_ag_emb', structures['p_anchor_graph_emb'])
                if 'n_anchor_graph_emb' in structures:
                    output_ag_emb(output, 'n_ag_emb', structures['n_anchor_graph_emb'])
                for path_with_emb in structures['dd_paths_with_emb_2_p']:
                    output.write('dd_path_2_p ' + ' ' + path_with_emb['path_emb'] + '\n')
                for path_with_emb in structures['dd_paths_with_emb_2_n']:
                    output.write('dd_path_2_n ' + ' ' + path_with_emb['path_emb'] + '\n')
                for path_with_emb in structures['dd_paths_with_emb_3']:
                    output.write('dd_path_3 ' + ' ' + path_with_emb['path_emb'] + '\n')
                for path_with_emb in structures['dd_paths_with_emb_5']:
                    output.write('dd_path_5 ' + ' ' + path_with_emb['path_emb'] + '\n')

            for no_dfs_edge in queries[key]['no_dfs_edges']:
                no_dfs_edge_key = str(no_dfs_edge[0]) + '-' + str(no_dfs_edge[1])
                structures = queries[key]['anchor_structures'][no_dfs_edge_key]
                output.write('no_dfs_edge ' + no_dfs_edge_key + '\n')
                ae_labels = structures['p_anchor_graph']['ae_labels']
                output.write('no_dfs_edge_labels ' + str(ae_labels[0]) + ' ' + str(ae_labels[1]) + '\n')
                if 'p_anchor_graph_emb' in structures:
                    output_ag_emb(output, 'p_ag_emb', structures['p_anchor_graph_emb'])
                if 'n_anchor_graph_emb' in structures:
                    output_ag_emb(output, 'n_ag_emb', structures['n_anchor_graph_emb'])
                for path_with_emb in structures['dd_paths_with_emb_2_p']:
                    output.write('dd_path_2_p ' + ' ' + path_with_emb['path_emb'] + '\n')
                for path_with_emb in structures['dd_paths_with_emb_2_n']:
                    output.write('dd_path_2_n ' + ' ' + path_with_emb['path_emb'] + '\n')
                for path_with_emb in structures['dd_paths_with_emb_3']:
                    output.write('dd_path_3 ' + ' ' + path_with_emb['path_emb'] + '\n')
                for path_with_emb in structures['dd_paths_with_emb_5']:
                    output.write('dd_path_5 ' + ' ' + path_with_emb['path_emb'] + '\n')

            no_dfs_edges_dict = queries[key]['no_dfs_edges_dict']
            for node in no_dfs_edges_dict:
                output.write('no_dfs_edge_dict ' + str(node))
                for i in range(len(no_dfs_edges_dict[node])):
                    output.write(' ' + str(no_dfs_edges_dict[node][i]))
                output.write('\n')
        output.close()











