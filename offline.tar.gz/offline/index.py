import time
import itertools
import numpy as np

from output import *


def emb_string(value_list):
    string = str(value_list[0])
    for i in range(len(value_list) - 1):
        string = string + '-' + str(value_list[i + 1])

    return string


def ae_matching_merge(ae_matching, anchor_edge):
    anchor_end_node = anchor_edge[0]
    if anchor_end_node in ae_matching:
        ae_matching[anchor_end_node].add(anchor_edge[1])
    else:
        ae_matching.update({anchor_end_node: {anchor_edge[1]}})


def anchor_graph_mapping(anchor_graph):
    nodes = anchor_graph['nodes']
    num_v = len(nodes)
    new_nodes = list(range(0, num_v))
    nodes_map = {nodes[i]: new_nodes[i] for i in range(num_v)}
    new_from_nodes = [nodes_map[node] for node in anchor_graph['from_nodes']]
    new_to_nodes = [nodes_map[node] for node in anchor_graph['to_nodes']]
    adj = np.zeros((num_v, num_v))
    for i in range(len(new_from_nodes)):
        adj[new_from_nodes[i]][new_to_nodes[i]] = 1
        adj[new_to_nodes[i]][new_from_nodes[i]] = 1

    anchor_graph_new = {'num_v': num_v, 'node_labels': anchor_graph['node_labels'], 'adj': adj}

    return anchor_graph_new


def p_n_sparse_mining(graph, node, threshold, sparse_ags_no_emb):
    """
       The function mines all substructures in a sparse anchor graph and remaps node IDs.
    """
    neighbors = graph['node_neighbors'][node]
    anchor_graphs = []
    for i in range(1, len(neighbors) + 1):
        com = list(itertools.combinations(neighbors, i))
        for m in range(len(com)):
            nodes = [node] + list(com[m])
            node_labels = [graph['node_labels'][node_id] for node_id in nodes]
            from_nodes, to_nodes = [], []
            for neighbor in com[m]:
                from_nodes.append(node)
                to_nodes.append(neighbor)
            sparse_ag = {'nodes': nodes, 'node_labels': node_labels, 'from_nodes': from_nodes, 'to_nodes': to_nodes}
            sparse_ag_new = anchor_graph_mapping(sparse_ag)

            # 'p_aes': {string(34-45): {'ae_labels': [34, 45], 'ae_matching': {v1: {v6, v2}, v2: {v1}}}, ...},
            # 'n_aes': {string(45-34): {'ae_labels': [45, 34], , 'ae_matching': {v1: {v6, v9}, v4: {v3}}}, ...}}
            p_aes, n_aes = {}, {}
            for neighbor in com[m]:
                p_ae = [node, neighbor]
                p_ae_labels = [graph['node_labels'][node], graph['node_labels'][neighbor]]
                p_ae_string = emb_string(p_ae_labels)
                if p_ae_string in p_aes:
                    ae_matching_merge(p_aes[p_ae_string]['ae_matching'], p_ae)
                else:
                    p_aes.update({p_ae_string: {'ae_labels': p_ae_labels, 'ae_matching': {p_ae[0]: {p_ae[1]}}}})
                if graph['degrees'][neighbor] > threshold:
                    n_ae = [neighbor, node]
                    n_ae_labels = [graph['node_labels'][neighbor], graph['node_labels'][node]]
                    n_ae_string = emb_string(n_ae_labels)
                    if n_ae_string in n_aes:
                        ae_matching_merge(n_aes[n_ae_string]['ae_matching'], n_ae)
                    else:
                        n_aes.update({n_ae_string: {'ae_labels': n_ae_labels, 'ae_matching': {n_ae[0]: {n_ae[1]}}}})
            sparse_ag_new.update({'p_aes': p_aes, 'n_aes': n_aes})
            anchor_graphs.append(sparse_ag_new)
            del sparse_ag, sparse_ag_new
    sparse_ags_no_emb.update({node: anchor_graphs})
    del neighbors, anchor_graphs


def dense_dense_2(graph, node, threshold):
    dd_2_edge = 0
    node_labels = graph['node_labels']
    neighbors = graph['node_neighbors'][node]
    dd_paths_p_emb, anchor_edges_p, dd_paths_n_emb, anchor_edges_n = [], [], [], []
    for neighbor in neighbors:
        if graph['degrees'][neighbor] > threshold:
            dd_2_edge += 1
            path_emb_p = str(-1) + '-' + str(node_labels[node]) + '-' + str(node_labels[neighbor])
            path_emb_n = str(node_labels[neighbor]) + '-' + str(node_labels[node]) + '-' + str(-1)
            dd_paths_p_emb.append(path_emb_p)
            anchor_edges_p.append([node, neighbor])
            dd_paths_n_emb.append(path_emb_n)
            anchor_edges_n.append([neighbor, node])

            noa_neighbors = neighbors.copy()
            noa_neighbors.remove(neighbor)
            for noa in noa_neighbors:
                path_emb_p = str(node_labels[noa]) + '-' + str(node_labels[node]) + '-' + str(node_labels[neighbor])
                path_emb_n = str(node_labels[neighbor]) + '-' + str(node_labels[node]) + '-' + str(node_labels[noa])
                dd_paths_p_emb.append(path_emb_p)
                anchor_edges_p.append([node, neighbor])
                dd_paths_n_emb.append(path_emb_n)
                anchor_edges_n.append([neighbor, node])

    return dd_paths_p_emb, anchor_edges_p, dd_paths_n_emb, anchor_edges_n, dd_2_edge


def dense_dense_3(graph, edge):
    node_labels = graph['node_labels']
    node_neighbors = graph['node_neighbors']
    noa_neighbors_0 = node_neighbors[edge[0]].copy()
    noa_neighbors_0.remove(edge[1])
    noa_neighbors_0.append('nan')
    noa_neighbors_1 = node_neighbors[edge[1]].copy()
    noa_neighbors_1.remove(edge[0])
    noa_neighbors_1.append('nan')
    dd_paths_emb, anchor_edges = [], []
    label_0 = node_labels[edge[0]]
    label_1 = node_labels[edge[1]]
    for i in range(len(noa_neighbors_0)):
        for j in range(len(noa_neighbors_1)):
            noa_neighbor_0 = noa_neighbors_0[i]
            noa_neighbor_1 = noa_neighbors_1[j]
            if noa_neighbor_0 == 'nan' and noa_neighbor_1 == 'nan':
                path_p_emb = str(-1) + '-' + str(label_0) + '-' + str(label_1) + '-' + str(-1)
                path_n_emb = str(-1) + '-' + str(label_1) + '-' + str(label_0) + '-' + str(-1)
            elif noa_neighbor_0 == 'nan' and noa_neighbor_1 != 'nan':
                path_p_emb = str(-1) + '-' + str(label_0) + '-' + str(label_1) + '-' + str(node_labels[noa_neighbor_1])
                path_n_emb = str(node_labels[noa_neighbor_1]) + '-' + str(label_1) + '-' + str(label_0) + '-' + str(-1)
                # (edge[0], edge[1], noa_neighbor_1) form a path with 3 length
            elif noa_neighbor_0 != 'nan' and noa_neighbor_1 == 'nan':
                path_p_emb = str(node_labels[noa_neighbor_0]) + '-' + str(label_0) + '-' + str(label_1) + '-' + str(-1)
                path_n_emb = str(-1) + '-' + str(label_1) + '-' + str(label_0) + '-' + str(node_labels[noa_neighbor_0])
            else:
                if noa_neighbor_0 != noa_neighbor_1:
                    path_p_emb = str(node_labels[noa_neighbor_0]) + '-' + str(label_0) + '-' + str(label_1) \
                                 + '-' + str(node_labels[noa_neighbor_1])
                    path_n_emb = str(node_labels[noa_neighbor_1]) + '-' + str(label_1) + '-' + str(label_0) \
                                 + '-' + str(node_labels[noa_neighbor_0])
                else:
                    path_p_emb = str(-2) + '-' + str(label_0) + '-' + str(label_1) + '-' + \
                                 str(node_labels[noa_neighbor_1])
                    path_n_emb = str(-2) + '-' + str(label_1) + '-' + str(label_0) + '-' + \
                                 str(node_labels[noa_neighbor_1])
                    # (edge[0], edge[1], noa_neighbor_1) form a triangle
            dd_paths_emb.append(path_p_emb)
            anchor_edges.append([edge[0], edge[1]])
            dd_paths_emb.append(path_n_emb)
            anchor_edges.append([edge[1], edge[0]])

    return dd_paths_emb, anchor_edges


def dense_dense_5(graph, edge):
    node_labels = graph['node_labels']
    node_neighbors = graph['node_neighbors']
    noa_neighbors_0 = node_neighbors[edge[0]].copy()
    noa_neighbors_0.remove(edge[1])
    noa_neighbors_0_hop = {}
    for noa_neighbor in noa_neighbors_0:
        hop_neighbors = node_neighbors[noa_neighbor].copy()
        hop_neighbors.remove(edge[0])
        hop_neighbors.append('nan')
        noa_neighbors_0_hop.update({noa_neighbor: hop_neighbors})
    noa_neighbors_0.append('nan')

    noa_neighbors_1 = node_neighbors[edge[1]].copy()
    noa_neighbors_1.remove(edge[0])
    noa_neighbors_1_hop = {}
    for noa_neighbor in noa_neighbors_1:
        hop_neighbors = node_neighbors[noa_neighbor].copy()
        hop_neighbors.remove(edge[1])
        hop_neighbors.append('nan')
        noa_neighbors_1_hop.update({noa_neighbor: list(set(hop_neighbors))})
    noa_neighbors_1.append('nan')

    dd_paths_emb, anchor_edges = [], []
    label_0 = node_labels[edge[0]]
    label_1 = node_labels[edge[1]]
    for i in range(len(noa_neighbors_0)):
        for j in range(len(noa_neighbors_1)):
            noa_neighbor_0 = noa_neighbors_0[i]
            noa_neighbor_1 = noa_neighbors_1[j]
            if noa_neighbor_0 != 'nan' and noa_neighbor_1 != 'nan':
                for node_0 in noa_neighbors_0_hop[noa_neighbor_0]:
                    for node_1 in noa_neighbors_1_hop[noa_neighbor_1]:
                        if node_0 != 'nan' and node_1 != 'nan':
                            original_path = [node_0, noa_neighbor_0, edge[0], edge[1], noa_neighbor_1, node_1]
                            if len(set(original_path)) == 6:
                                path_p_emb = str(node_labels[node_0]) + '-' + str(node_labels[noa_neighbor_0]) + '-' + \
                                             str(label_0) + '-' + str(label_1) + '-' + str(node_labels[noa_neighbor_1]) \
                                             + '-' + str(node_labels[node_1])
                                path_n_emb = str(node_labels[node_1]) + '-' + str(node_labels[noa_neighbor_1]) + '-' + \
                                             str(label_1) + '-' + str(label_0) + '-' + str(node_labels[noa_neighbor_0]) \
                                             + '-' + str(node_labels[node_0])
                                dd_paths_emb.append(path_p_emb)
                                anchor_edges.append([edge[0], edge[1]])
                                dd_paths_emb.append(path_n_emb)
                                anchor_edges.append([edge[1], edge[0]])
                            elif noa_neighbor_0 == noa_neighbor_1 and node_0 == edge[1] and node_1 == edge[0]:
                                path_p_emb = str(-2) + '-' + str(label_0) + '-' + str(label_1) + '-' + \
                                             str(node_labels[noa_neighbor_0])
                                path_n_emb = str(-2) + '-' + str(label_1) + '-' + str(label_0) + '-' + \
                                             str(node_labels[noa_neighbor_0])
                                dd_paths_emb.append(path_p_emb)
                                anchor_edges.append([edge[0], edge[1]])
                                dd_paths_emb.append(path_n_emb)
                                anchor_edges.append([edge[1], edge[0]])
                            elif noa_neighbor_0 == noa_neighbor_1 and node_0 == edge[1] and node_1 != edge[0]:
                                path_p_emb = str(-3) + '-' + str(label_0) + '-' + str(label_1) + '-' + \
                                             str(node_labels[noa_neighbor_0]) + '-' + str(node_labels[node_1])
                                path_n_emb = str(-3) + '-' + str(label_1) + '-' + str(label_0) + '-' + \
                                             str(node_labels[noa_neighbor_1]) + '-' + str(node_labels[node_1])
                                dd_paths_emb.append(path_p_emb)
                                anchor_edges.append([edge[0], edge[1]])
                                dd_paths_emb.append(path_n_emb)
                                anchor_edges.append([edge[1], edge[0]])
                            elif noa_neighbor_0 == noa_neighbor_1 and node_0 != edge[1] and node_1 == edge[0]:
                                path_p_emb = str(-3) + '-' + str(label_0) + '-' + str(label_1) + '-' + \
                                             str(node_labels[noa_neighbor_0]) + '-' + str(node_labels[node_0])
                                path_n_emb = str(-3) + '-' + str(label_1) + '-' + str(label_0) + '-' + \
                                             str(node_labels[noa_neighbor_1]) + '-' + str(node_labels[node_0])
                                dd_paths_emb.append(path_p_emb)
                                anchor_edges.append([edge[0], edge[1]])
                                dd_paths_emb.append(path_n_emb)
                                anchor_edges.append([edge[1], edge[0]])
                            elif noa_neighbor_0 == noa_neighbor_1 and node_0 != edge[1] and node_1 != edge[0] \
                                    and node_0 == node_1:
                                path_p_emb = str(-3) + '-' + str(label_0) + '-' + str(label_1) + '-' + \
                                             str(node_labels[noa_neighbor_0]) + '-' + str(node_labels[node_0])
                                path_n_emb = str(-3) + '-' + str(label_1) + '-' + str(label_0) + '-' + \
                                             str(node_labels[noa_neighbor_0]) + '-' + str(node_labels[node_0])
                                dd_paths_emb.append(path_p_emb)
                                anchor_edges.append([edge[0], edge[1]])
                                dd_paths_emb.append(path_n_emb)
                                anchor_edges.append([edge[1], edge[0]])
                            elif noa_neighbor_0 == noa_neighbor_1 and node_0 != edge[1] and node_1 != edge[0] \
                                    and node_0 != node_1:
                                path_p_emb = str(-11) + '-' + str(label_0) + '-' + str(label_1) + '-' + \
                                             str(node_labels[noa_neighbor_1]) + '-' + str(node_labels[node_0]) + \
                                             '-' + str(node_labels[node_1])
                                path_n_emb = str(-11) + '-' + str(label_1) + '-' + str(label_0) + '-' + \
                                             str(node_labels[noa_neighbor_1]) + '-' + str(node_labels[node_1]) + \
                                             '-' + str(node_labels[node_0])
                                dd_paths_emb.append(path_p_emb)
                                anchor_edges.append([edge[0], edge[1]])
                                dd_paths_emb.append(path_n_emb)
                                anchor_edges.append([edge[1], edge[0]])
                            elif noa_neighbor_0 != noa_neighbor_1 and node_1 == edge[0] and node_0 != noa_neighbor_1 \
                                    and node_0 != edge[1]:
                                path_p_emb = str(-6) + '-' + str(label_0) + '-' + str(label_1) + '-' + \
                                             str(node_labels[noa_neighbor_0]) + '-' + str(node_labels[node_0]) + \
                                             '-' + str(node_labels[noa_neighbor_1])
                                path_n_emb = str(-6) + '-' + str(label_1) + '-' + str(label_0) + '-' + \
                                             str(node_labels[noa_neighbor_1]) + '-' + str(node_labels[noa_neighbor_0]) + \
                                             '-' + str(node_labels[node_0])
                                dd_paths_emb.append(path_p_emb)
                                anchor_edges.append([edge[0], edge[1]])
                                dd_paths_emb.append(path_n_emb)
                                anchor_edges.append([edge[1], edge[0]])
                            elif noa_neighbor_0 != noa_neighbor_1 and node_0 == edge[1] and node_1 != noa_neighbor_0 \
                                    and node_1 != edge[0]:
                                path_p_emb = str(-6) + '-' + str(label_0) + '-' + str(label_1) + '-' + \
                                             str(node_labels[noa_neighbor_0]) + '-' + str(node_labels[noa_neighbor_1]) + \
                                             '-' + str(node_labels[node_1])
                                path_n_emb = str(-6) + '-' + str(label_1) + '-' + str(label_0) + '-' + \
                                             str(node_labels[noa_neighbor_1]) + '-' + str(node_labels[node_1]) + \
                                             '-' + str(node_labels[noa_neighbor_0])
                                dd_paths_emb.append(path_p_emb)
                                anchor_edges.append([edge[0], edge[1]])
                                dd_paths_emb.append(path_n_emb)
                                anchor_edges.append([edge[1], edge[0]])
                            elif noa_neighbor_0 != noa_neighbor_1 and node_0 == noa_neighbor_1 and node_1 == noa_neighbor_0:
                                path_p_emb = str(-5) + '-' + str(label_0) + '-' + str(label_1) + '-' + \
                                             str(node_labels[noa_neighbor_0]) + '-' + str(node_labels[noa_neighbor_1])
                                path_n_emb = str(-5) + '-' + str(label_1) + '-' + str(label_0) + '-' + \
                                             str(node_labels[noa_neighbor_1]) + '-' + str(node_labels[noa_neighbor_0])
                                dd_paths_emb.append(path_p_emb)
                                anchor_edges.append([edge[0], edge[1]])
                                dd_paths_emb.append(path_n_emb)
                                anchor_edges.append([edge[1], edge[0]])
                            elif noa_neighbor_0 != noa_neighbor_1 and node_0 == noa_neighbor_1 and node_1 != \
                                    noa_neighbor_0 and node_1 != edge[0]:
                                path_p_emb = str(-7) + '-' + str(label_0) + '-' + str(label_1) + '-' + \
                                             str(node_labels[noa_neighbor_0]) + '-' + str(node_labels[noa_neighbor_1]) + \
                                             '-' + str(node_labels[node_1])
                                path_n_emb = str(-7) + '-' + str(label_1) + '-' + str(label_0) + '-' + \
                                             str(node_labels[noa_neighbor_1]) + '-' + str(node_labels[node_1]) + \
                                             '-' + str(node_labels[noa_neighbor_0])
                                dd_paths_emb.append(path_p_emb)
                                anchor_edges.append([edge[0], edge[1]])
                                dd_paths_emb.append(path_n_emb)
                                anchor_edges.append([edge[1], edge[0]])
                            elif noa_neighbor_0 != noa_neighbor_1 and node_1 == noa_neighbor_0 and node_0 != \
                                    noa_neighbor_1 and node_0 != edge[1]:
                                path_p_emb = str(-7) + '-' + str(label_0) + '-' + str(label_1) + '-' + \
                                             str(node_labels[noa_neighbor_0]) + '-' + str(node_labels[node_0]) + \
                                             '-' + str(node_labels[noa_neighbor_1])
                                path_n_emb = str(-7) + '-' + str(label_1) + '-' + str(label_0) + '-' + \
                                             str(node_labels[noa_neighbor_1]) + '-' + str(node_labels[noa_neighbor_0]) + \
                                             '-' + str(node_labels[node_0])
                                dd_paths_emb.append(path_p_emb)
                                anchor_edges.append([edge[0], edge[1]])
                                dd_paths_emb.append(path_n_emb)
                                anchor_edges.append([edge[1], edge[0]])
                            elif noa_neighbor_0 != noa_neighbor_1 and node_0 == noa_neighbor_1 and node_1 == edge[0]:
                                path_p_emb = str(-8) + '-' + str(label_0) + '-' + str(label_1) + '-' + \
                                             str(node_labels[noa_neighbor_0]) + '-' + str(node_labels[noa_neighbor_1])
                                path_n_emb = str(-8) + '-' + str(label_1) + '-' + str(label_0) + '-' + \
                                             str(node_labels[noa_neighbor_1]) + '-' + str(node_labels[noa_neighbor_0])
                                dd_paths_emb.append(path_p_emb)
                                anchor_edges.append([edge[0], edge[1]])
                                dd_paths_emb.append(path_n_emb)
                                anchor_edges.append([edge[1], edge[0]])
                            elif noa_neighbor_0 != noa_neighbor_1 and node_1 == noa_neighbor_0 and node_0 == edge[1]:
                                path_p_emb = str(-8) + '-' + str(label_0) + '-' + str(label_1) + '-' + \
                                             str(node_labels[noa_neighbor_0]) + '-' + str(node_labels[noa_neighbor_1])
                                path_n_emb = str(-8) + '-' + str(label_1) + '-' + str(label_0) + '-' + \
                                             str(node_labels[noa_neighbor_1]) + '-' + str(node_labels[noa_neighbor_0])
                                dd_paths_emb.append(path_p_emb)
                                anchor_edges.append([edge[0], edge[1]])
                                dd_paths_emb.append(path_n_emb)
                                anchor_edges.append([edge[1], edge[0]])
                            elif noa_neighbor_0 != noa_neighbor_1 and node_0 == edge[1] and node_1 == edge[0]:
                                path_p_emb = str(-9) + '-' + str(label_0) + '-' + str(label_1) + '-' + \
                                             str(node_labels[noa_neighbor_0]) + '-' + str(node_labels[noa_neighbor_1])
                                path_n_emb = str(-9) + '-' + str(label_1) + '-' + str(label_0) + '-' + \
                                             str(node_labels[noa_neighbor_1]) + '-' + str(node_labels[noa_neighbor_0])
                                dd_paths_emb.append(path_p_emb)
                                anchor_edges.append([edge[0], edge[1]])
                                dd_paths_emb.append(path_n_emb)
                                anchor_edges.append([edge[1], edge[0]])
                            elif noa_neighbor_0 != noa_neighbor_1 and node_0 == node_1:
                                path_p_emb = str(-10) + '-' + str(label_0) + '-' + str(label_1) + '-' + \
                                             str(node_labels[noa_neighbor_0]) + '-' + str(node_labels[noa_neighbor_1]) \
                                             + '-' + str(node_labels[node_0])
                                path_n_emb = str(-10) + '-' + str(label_1) + '-' + str(label_0) + '-' + \
                                             str(node_labels[noa_neighbor_1]) + '-' + str(node_labels[noa_neighbor_0]) \
                                             + '-' + str(node_labels[node_0])
                                dd_paths_emb.append(path_p_emb)
                                anchor_edges.append([edge[0], edge[1]])
                                dd_paths_emb.append(path_n_emb)
                                anchor_edges.append([edge[1], edge[0]])
                            else:
                                print("miss case testing 1:", [node_0, noa_neighbor_0, edge[0], edge[1], noa_neighbor_1,
                                                               node_1])
                        elif node_0 == 'nan' and node_1 == 'nan' and noa_neighbor_0 == noa_neighbor_1:
                            path_p_emb = str(-2) + '-' + str(label_0) + '-' + str(label_1) + '-' + \
                                         str(node_labels[noa_neighbor_0])
                            path_n_emb = str(-2) + '-' + str(label_1) + '-' + str(label_0) + '-' + \
                                         str(node_labels[noa_neighbor_1])
                            dd_paths_emb.append(path_p_emb)
                            anchor_edges.append([edge[0], edge[1]])
                            dd_paths_emb.append(path_n_emb)
                            anchor_edges.append([edge[1], edge[0]])
                        elif node_0 == 'nan' and node_1 == 'nan' and noa_neighbor_0 != noa_neighbor_1:
                            path_p_emb = str(-1) + '-' + str(node_labels[noa_neighbor_0]) + '-' + str(label_0) + '-' + \
                                         str(label_1) + '-' + str(node_labels[noa_neighbor_1]) + '-' + str(-1)
                            path_n_emb = str(-1) + '-' + str(node_labels[noa_neighbor_1]) + '-' + str(label_1) + '-' + \
                                         str(label_0) + '-' + str(node_labels[noa_neighbor_0]) + '-' + str(-1)
                            dd_paths_emb.append(path_p_emb)
                            anchor_edges.append([edge[0], edge[1]])
                            dd_paths_emb.append(path_n_emb)
                            anchor_edges.append([edge[1], edge[0]])
                        elif node_0 == 'nan' and node_1 != 'nan':
                            original_path = [noa_neighbor_0, edge[0], edge[1], noa_neighbor_1, node_1]
                            if len(set(original_path)) == 5:
                                path_p_emb = str(-1) + '-' + str(node_labels[noa_neighbor_0]) + '-' + str(label_0) + \
                                             '-' + str(label_1) + '-' + str(node_labels[noa_neighbor_1]) + '-' + \
                                             str(node_labels[node_1])
                                path_n_emb = str(node_labels[node_1]) + '-' + str(node_labels[noa_neighbor_1]) + '-' + \
                                             str(label_1) + '-' + str(label_0) + '-' + str(node_labels[noa_neighbor_0]) \
                                             + '-' + str(-1)
                                dd_paths_emb.append(path_p_emb)
                                anchor_edges.append([edge[0], edge[1]])
                                dd_paths_emb.append(path_n_emb)
                                anchor_edges.append([edge[1], edge[0]])
                            elif noa_neighbor_0 == noa_neighbor_1 and node_1 == edge[0]:
                                path_p_emb = str(-2) + '-' + str(label_0) + '-' + str(label_1) + '-' + \
                                             str(node_labels[noa_neighbor_0])
                                path_n_emb = str(-2) + '-' + str(label_1) + '-' + str(label_0) + '-' + \
                                             str(node_labels[noa_neighbor_1])
                                dd_paths_emb.append(path_p_emb)
                                anchor_edges.append([edge[0], edge[1]])
                                dd_paths_emb.append(path_n_emb)
                                anchor_edges.append([edge[1], edge[0]])
                            elif noa_neighbor_0 == noa_neighbor_1 and node_1 != edge[0]:
                                path_p_emb = str(-3) + '-' + str(label_0) + '-' + str(label_1) + '-' + \
                                             str(node_labels[noa_neighbor_0]) + '-' + str(node_labels[node_1])
                                path_n_emb = str(-3) + '-' + str(label_1) + '-' + str(label_0) + '-' + \
                                             str(node_labels[noa_neighbor_1]) + '-' + str(node_labels[node_1])
                                dd_paths_emb.append(path_p_emb)
                                anchor_edges.append([edge[0], edge[1]])
                                dd_paths_emb.append(path_n_emb)
                                anchor_edges.append([edge[1], edge[0]])
                            elif noa_neighbor_0 != noa_neighbor_1 and node_1 == edge[0]:
                                path_p_emb = str(-4) + '-' + str(label_0) + '-' + str(label_1) + '-' + \
                                             str(node_labels[noa_neighbor_0]) + '-' + str(node_labels[noa_neighbor_1])
                                path_n_emb = str(-4) + '-' + str(label_1) + '-' + str(label_0) + '-' + \
                                             str(node_labels[noa_neighbor_1]) + '-' + str(node_labels[noa_neighbor_0])
                                dd_paths_emb.append(path_p_emb)
                                anchor_edges.append([edge[0], edge[1]])
                                dd_paths_emb.append(path_n_emb)
                                anchor_edges.append([edge[1], edge[0]])
                            elif noa_neighbor_0 != noa_neighbor_1 and node_1 == noa_neighbor_0:
                                path_p_emb = str(-5) + '-' + str(label_0) + '-' + str(label_1) + '-' + \
                                             str(node_labels[noa_neighbor_0]) + '-' + str(node_labels[noa_neighbor_1])
                                path_n_emb = str(-5) + '-' + str(label_1) + '-' + str(label_0) + '-' + \
                                             str(node_labels[noa_neighbor_1]) + '-' + str(node_labels[noa_neighbor_0])
                                dd_paths_emb.append(path_p_emb)
                                anchor_edges.append([edge[0], edge[1]])
                                dd_paths_emb.append(path_n_emb)
                                anchor_edges.append([edge[1], edge[0]])
                            else:
                                print("miss case testing 2:",
                                      [noa_neighbor_0, edge[0], edge[1], noa_neighbor_1, node_1])
                        elif node_0 != 'nan' and node_1 == 'nan':
                            original_path = [node_0, noa_neighbor_0, edge[0], edge[1], noa_neighbor_1]
                            if len(set(original_path)) == 5:
                                path_p_emb = str(node_labels[node_0]) + '-' + str(node_labels[noa_neighbor_0]) + '-' + \
                                             str(label_0) + '-' + str(label_1) + '-' + str(node_labels[noa_neighbor_1]) \
                                             + '-' + str(-1)
                                path_n_emb = str(-1) + '-' + str(node_labels[noa_neighbor_1]) + '-' + \
                                             str(label_1) + '-' + str(label_0) + '-' + str(node_labels[noa_neighbor_0]) \
                                             + '-' + str(node_labels[node_0])
                                dd_paths_emb.append(path_p_emb)
                                anchor_edges.append([edge[0], edge[1]])
                                dd_paths_emb.append(path_n_emb)
                                anchor_edges.append([edge[1], edge[0]])
                            elif noa_neighbor_0 == noa_neighbor_1 and node_0 == edge[1]:
                                path_p_emb = str(-2) + '-' + str(label_0) + '-' + str(label_1) + '-' + \
                                             str(node_labels[noa_neighbor_0])
                                path_n_emb = str(-2) + '-' + str(label_1) + '-' + str(label_0) + '-' + \
                                             str(node_labels[noa_neighbor_1])
                                dd_paths_emb.append(path_p_emb)
                                anchor_edges.append([edge[0], edge[1]])
                                dd_paths_emb.append(path_n_emb)
                                anchor_edges.append([edge[1], edge[0]])
                            elif noa_neighbor_0 == noa_neighbor_1 and node_0 != edge[1]:
                                path_p_emb = str(-3) + '-' + str(label_0) + '-' + str(label_1) + '-' + \
                                             str(node_labels[noa_neighbor_0]) + '-' + str(node_labels[node_0])
                                path_n_emb = str(-3) + '-' + str(label_1) + '-' + str(label_0) + '-' + \
                                             str(node_labels[noa_neighbor_1]) + '-' + str(node_labels[node_0])
                                dd_paths_emb.append(path_p_emb)
                                anchor_edges.append([edge[0], edge[1]])
                                dd_paths_emb.append(path_n_emb)
                                anchor_edges.append([edge[1], edge[0]])
                            elif noa_neighbor_0 != noa_neighbor_1 and node_0 == edge[1]:
                                path_p_emb = str(-4) + '-' + str(label_0) + '-' + str(label_1) + '-' + \
                                             str(node_labels[noa_neighbor_0]) + '-' + str(node_labels[noa_neighbor_1])
                                path_n_emb = str(-4) + '-' + str(label_1) + '-' + str(label_0) + '-' + \
                                             str(node_labels[noa_neighbor_1]) + '-' + str(node_labels[noa_neighbor_0])
                                dd_paths_emb.append(path_p_emb)
                                anchor_edges.append([edge[0], edge[1]])
                                dd_paths_emb.append(path_n_emb)
                                anchor_edges.append([edge[1], edge[0]])
                            elif noa_neighbor_0 != noa_neighbor_1 and node_0 == noa_neighbor_1:
                                path_p_emb = str(-5) + '-' + str(label_0) + '-' + str(label_1) + '-' + \
                                             str(node_labels[noa_neighbor_0]) + '-' + str(node_labels[node_0])
                                path_n_emb = str(-5) + '-' + str(label_1) + '-' + str(label_0) + '-' + \
                                             str(node_labels[noa_neighbor_1]) + '-' + str(node_labels[noa_neighbor_0])
                                dd_paths_emb.append(path_p_emb)
                                anchor_edges.append([edge[0], edge[1]])
                                dd_paths_emb.append(path_n_emb)
                                anchor_edges.append([edge[1], edge[0]])
                            else:
                                print("miss case testing 3:",
                                      [node_0, noa_neighbor_0, edge[0], edge[1], noa_neighbor_1])
                        else:
                            print("miss case testing 4",
                                  [node_0, noa_neighbor_0, edge[0], edge[1], noa_neighbor_1, node_1])
            elif noa_neighbor_0 == 'nan' and noa_neighbor_1 != 'nan':
                for node in noa_neighbors_1_hop[noa_neighbor_1]:
                    if node == 'nan':
                        path_p_emb = str(-1) + '-' + str(-1) + '-' + str(label_0) + '-' + str(label_1) + '-' + \
                                     str(node_labels[noa_neighbor_1]) + '-' + str(-1)
                        path_n_emb = str(-1) + '-' + str(node_labels[noa_neighbor_1]) + '-' + str(label_1) + '-' + \
                                     str(label_0) + '-' + str(-1) + '-' + str(-1)
                        dd_paths_emb.append(path_p_emb)
                        anchor_edges.append([edge[0], edge[1]])
                        dd_paths_emb.append(path_n_emb)
                        anchor_edges.append([edge[1], edge[0]])
                    else:
                        # original_path = [edge[0], edge[1], noa_neighbor_1, node]
                        if node == edge[0]:
                            path_p_emb = str(-2) + '-' + str(label_0) + '-' + str(label_1) + '-' + \
                                         str(node_labels[noa_neighbor_1])
                            path_n_emb = str(-2) + '-' + str(label_1) + '-' + str(label_0) + '-' + \
                                         str(node_labels[noa_neighbor_1])
                        else:
                            path_p_emb = str(-1) + '-' + str(-1) + '-' + str(label_0) + '-' + str(label_1) + '-' + \
                                         str(node_labels[noa_neighbor_1]) + '-' + str(node_labels[node])
                            path_n_emb = str(node_labels[node]) + '-' + str(node_labels[noa_neighbor_1]) + '-' + \
                                         str(label_1) + '-' + str(label_0) + '-' + str(-1) + '-' + str(-1)
                        dd_paths_emb.append(path_p_emb)
                        anchor_edges.append([edge[0], edge[1]])
                        dd_paths_emb.append(path_n_emb)
                        anchor_edges.append([edge[1], edge[0]])
            elif noa_neighbor_0 != 'nan' and noa_neighbor_1 == 'nan':
                for node in noa_neighbors_0_hop[noa_neighbor_0]:
                    if node == 'nan':
                        path_p_emb = str(-1) + '-' + str(node_labels[noa_neighbor_0]) + '-' + str(label_0) + '-' + \
                                     str(label_1) + '-' + str(-1) + '-' + str(-1)
                        path_n_emb = str(-1) + '-' + str(-1) + '-' + str(label_1) + '-' + str(label_0) + '-' + \
                                     str(node_labels[noa_neighbor_0]) + '-' + str(-1)
                        dd_paths_emb.append(path_p_emb)
                        anchor_edges.append([edge[0], edge[1]])
                        dd_paths_emb.append(path_n_emb)
                        anchor_edges.append([edge[1], edge[0]])
                    else:
                        # original_path = [node, noa_neighbor_0, edge[0], edge[1]]
                        if node == edge[1]:
                            path_p_emb = str(-2) + '-' + str(label_0) + '-' + str(label_1) + '-' + \
                                         str(node_labels[noa_neighbor_0])
                            path_n_emb = str(-2) + '-' + str(label_1) + '-' + str(label_0) + '-' + \
                                         str(node_labels[noa_neighbor_0])
                        else:
                            path_p_emb = str(node_labels[node]) + '-' + str(node_labels[noa_neighbor_0]) + '-' + \
                                         str(label_0) + '-' + str(label_1) + '-' + str(-1) + '-' + str(-1)
                            path_n_emb = str(-1) + '-' + str(-1) + '-' + str(label_1) + '-' + str(label_0) + '-' + \
                                         str(node_labels[noa_neighbor_0]) + '-' + str(node_labels[node])
                        dd_paths_emb.append(path_p_emb)
                        anchor_edges.append([edge[0], edge[1]])
                        dd_paths_emb.append(path_n_emb)
                        anchor_edges.append([edge[1], edge[0]])
            else:
                path_p_emb = str(-1) + '-' + str(-1) + '-' + str(label_0) + '-' + str(label_1) + '-' + str(
                    -1) + '-' + str(-1)
                path_n_emb = str(-1) + '-' + str(-1) + '-' + str(label_1) + '-' + str(label_0) + '-' + str(
                    -1) + '-' + str(-1)
                dd_paths_emb.append(path_p_emb)
                anchor_edges.append([edge[0], edge[1]])
                dd_paths_emb.append(path_n_emb)
                anchor_edges.append([edge[1], edge[0]])

    return dd_paths_emb, anchor_edges


def dense_dense_index(dd_paths_emb, anchor_edges, dd_index):
    """
       The function builds the dense-dense index for 2 or 5 paths.
    """
    # path = [-1, edge[0], edge[1], -1]
    # path = [-1, edge[0], edge[1], neighbors_1[j]]
    # path = [neighbors_0[i], edge[0], edge[1], -1]
    # path = [neighbors_0[i], edge[0], edge[1], neighbors_1[j]]
    # path = [-2, edge[0], edge[1], neighbors_1[j]]
    len_dd_paths_emb = len(dd_paths_emb)
    for i in range(len_dd_paths_emb):
        path_emb = dd_paths_emb[i]
        anchor_edge = anchor_edges[i]
        if path_emb in dd_index:
            matching = dd_index[path_emb]  # matching is a dict
            if anchor_edge[0] in matching:
                dd_index[path_emb][anchor_edge[0]].add(anchor_edge[1])
            else:
                dd_index[path_emb].update({anchor_edge[0]: {anchor_edge[1]}})
        else:
            dd_index.update({path_emb: {anchor_edge[0]: {anchor_edge[1]}}})
    # dd_index is {str(path_emb): {anchor_end_node: {anchor_node,...}, anchor_end_node: {anchor_node,...}, ...}, ...}


def data_decompose_path(graph, threshold, dd_path_mode, dd_path_threshold):
    """
       The function decomposes the data graph edges into 3 categories:
       sparse-sparse edges, dense-sparse edges (i.e. sparse nodes) and dense-dense edges.
    """
    dd_2_edges, dd_3_edges, dd_5_edges, paths_bef_merge_2_p, paths_bef_merge_2_n, paths_bef_merge_3, paths_bef_merge_5 = 0, 0, 0, 0, 0, 0, 0
    dd_index_2_p, dd_index_2_n, dd_index_3, dd_index_5 = {}, {}, {}, {}
    print("Start mining dense-dense paths:")
    if dd_path_mode == '3' or dd_path_mode == '3-5':
        for i in range(len(graph['edges'])):
            edge = graph['edges'][i]
            if graph['degrees'][edge[0]] > threshold and graph['degrees'][edge[1]] > threshold:
                if dd_path_threshold == 'nan':
                    dd_3_edges += 1
                    dd_paths_emb_3, anchor_edges_3 = dense_dense_3(graph, edge)
                    paths_bef_merge_3 += len(dd_paths_emb_3)
                    dense_dense_index(dd_paths_emb_3, anchor_edges_3, dd_index_3)
                    del dd_paths_emb_3, anchor_edges_3
                else:
                    if graph['degrees'][edge[0]] <= dd_path_threshold and graph['degrees'][edge[1]] <= dd_path_threshold:
                        dd_5_edges += 1
                        dd_paths_emb_5, anchor_edges_5 = dense_dense_5(graph, edge)
                        dense_dense_index(dd_paths_emb_5, anchor_edges_5, dd_index_5)
                        del dd_paths_emb_5, anchor_edges_5
                    else:
                        dd_3_edges += 1
                        dd_paths_emb_3, anchor_edges_3 = dense_dense_3(graph, edge)
                        paths_bef_merge_3 += len(dd_paths_emb_3)
                        dense_dense_index(dd_paths_emb_3, anchor_edges_3, dd_index_3)
                        del dd_paths_emb_3, anchor_edges_3

            if i % 100000 == 0:
                current_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
                print("Current time:", current_time)
                print("Current processed edges:", i)
                print(f"Current paths in dense-dense-3 index is {len(dd_index_3)}")
                if dd_path_threshold != 'nan':
                    print(f"Current paths in dense-dense-5 index is {len(dd_index_5)}")
                print("-" * 56)
    elif dd_path_mode == '2':
        for i in range(len(graph['nodes'])):
            node = graph['nodes'][i]
            if graph['degrees'][node] > threshold:
                dd_paths_p_emb_2, anchor_edges_p_2, dd_paths_n_emb_2, anchor_edges_n_2, dd_2_edge = \
                    dense_dense_2(graph, node, threshold)
                dd_2_edges += dd_2_edge
                paths_bef_merge_2_p += len(dd_paths_p_emb_2)
                paths_bef_merge_2_n += len(dd_paths_n_emb_2)
                dense_dense_index(dd_paths_p_emb_2, anchor_edges_p_2, dd_index_2_p)
                dense_dense_index(dd_paths_n_emb_2, anchor_edges_n_2, dd_index_2_n)
                del dd_paths_p_emb_2, anchor_edges_p_2, dd_paths_n_emb_2, anchor_edges_n_2

            if i % 100000 == 0:
                current_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
                print("Current time:", current_time)
                print("Current processed node:", i)
                print(f"Current paths in dense-dense-2-p index is {len(dd_index_2_p)}")
                print(f"Current paths in dense-dense-2-n index is {len(dd_index_2_n)}")
                print("-" * 56)
    else:
        print("Error: There is no this dd-path mode.")
    print("-" * 56)

    dd_path_num = {"paths_before_merge_2_p": paths_bef_merge_2_p, "paths_before_merge_2_n": paths_bef_merge_2_n, 
                   "paths_before_merge_3": paths_bef_merge_3, "paths_before_merge_5": paths_bef_merge_5, 
                   "dd_2_edges": int(dd_2_edges / 2), "dd_3_edges": dd_3_edges, "dd_5_edges": dd_5_edges}

    return dd_index_2_p, dd_index_2_n, dd_index_3, dd_index_5, dd_path_num


def data_decompose_graph(graph, threshold):
    """
       The function decomposes the data graph edges into 3 categories:
       sparse-sparse edges, dense-sparse edges (i.e. sparse nodes) and dense-dense edges.
    """
    sparse_node_num = 0
    sparse_ags_no_emb = {}
    print("Start mining sparse anchor graphs:")
    for i in range(len(graph['nodes'])):
        node = graph['nodes'][i]
        if threshold >= graph['degrees'][node] > 0:
            p_n_sparse_mining(graph, node, threshold, sparse_ags_no_emb)
            sparse_node_num += 1

        if i % 100000 == 0:
            current_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
            print("Current time:", current_time)
            print("Current processed node:", i)
            print(f"Current sparse anchor graphs in sparse_ags_no_emb is {statistics_sparse_ags(sparse_ags_no_emb)}")
            print("-" * 56)

    return sparse_ags_no_emb, sparse_node_num


def truncate_value(value, emb_precision):
    if emb_precision >= 1:
        integer = int(value / emb_precision)
        out_value = integer * emb_precision
    else:
        multiplier = 1 / emb_precision
        int_tmp = int(value * multiplier)
        out_remainder = int(int_tmp % multiplier) / multiplier
        out_value = int(value) + out_remainder

    return out_value


def truncate(embedding, emb_precision):
    truncated_emb = []
    for i in range(len(embedding)):
        value = truncate_value(embedding[i], emb_precision)
        truncated_emb.append(value)

    return truncated_emb


def attach_emb_index(index_key_ids, gnn_data_lp, index_no_emb, emb_truncation):
    for i in range(len(index_key_ids)):
        ids = index_key_ids[i]
        emb = gnn_data_lp['index_test'][i]
        emb = truncate(emb, emb_truncation)
        index_no_emb[ids[0]][ids[1]].update({'emb': emb})


def attach_emb_query(query_substructure_key_ids, gnn_data_lp, queries, emb_truncation):
    queries_lp_key = ['query_p_test', 'query_n_test']
    emb_key = ['p_anchor_graph_emb', 'n_anchor_graph_emb']
    for i in range(len(query_substructure_key_ids)):
        ids = query_substructure_key_ids[i]
        for j in range(len(queries_lp_key)):
            emb = gnn_data_lp[queries_lp_key[j]][i]
            emb = truncate(emb, emb_truncation)
            queries[ids[0]]['anchor_structures'][ids[1]].update({emb_key[j]: emb})


def merge_aes(sparse_aes, index_aes):
    for ae_string in sparse_aes:
        if ae_string in index_aes:
            sparse_ae_matching = sparse_aes[ae_string]['ae_matching']
            for from_node in sparse_ae_matching:
                node_matching = sparse_ae_matching[from_node]
                for to_node in node_matching:
                    ae = [from_node, to_node]
                    ae_matching_merge(index_aes[ae_string]['ae_matching'], ae)
        else:
            index_aes.update({ae_string: sparse_aes[ae_string]})


def merge_sparse_index(sparse_ags_no_emb):
    # sparse index format: {string(1.23-4.25): {'sparse_ag_emb': [1.23, 4.25],
    # 'p_aes': {string(34-45): {'ae_labels': [34, 45], 'ae_matching': {v1: {v6, v2}, v2: {v1}}}, ...},
    # 'n_aes': {string(45-34): {'ae_labels': [45, 34], , 'ae_matching': {v1: {v6, v9}, v4: {v3}}}, ...}}
    index = {}
    for node in sparse_ags_no_emb:
        for i in range(len(sparse_ags_no_emb[node])):
            sparse_ag = sparse_ags_no_emb[node][i]
            sparse_ag_emb_string = emb_string(sparse_ag['emb'])
            if sparse_ag_emb_string in index:
                merge_aes(sparse_ag['p_aes'], index[sparse_ag_emb_string]['p_aes'])
                merge_aes(sparse_ag['n_aes'], index[sparse_ag_emb_string]['n_aes'])
            else:
                index.update({sparse_ag_emb_string: {'sparse_ag_emb': sparse_ag['emb'],
                                                     'p_aes': sparse_ag['p_aes'], 'n_aes': sparse_ag['n_aes']}})

    return index
