import json

from read import *
from growth import *
from output import *
from gnn_utils import *
from gnn_trainer import *


"""Input parameters"""
data_set = 'yeast'
gnn_model_name = 'GIN'  # GAT  GIN
emb_dimension = 3

"""default parameters"""
ds_threshold = {'dblp': 10, 'hprd': 14, 'patents': 6, 'wordnet': 12,
                'yeast': 16, 'youtube': 8, 'rg': 10, 'ws': 10, 'ba': 12}
emb_precision = 100  # embedded precision
# 10 is retained to 10 integer digits, and 0.1 is retained to 1 decimal place.
# You can select a 'emb_precision' value in {..., 100, 10, 1, 0.1, 0.01, ...}
dd_path_modes = {'dblp': '3', 'hprd': '3', 'patents': '2', 'wordnet': '3',
                 'yeast': '3', 'youtube': '2', 'rg': '3', 'ws': '3', 'ba': '3'}   # '2', '3', '3-5'
dd_path_thresholds = {'dblp': 'nan', 'hprd': 'nan', 'patents': 'nan', 'wordnet': 'nan',
                      'yeast': 'nan', 'youtube': 'nan', 'rg': 'nan', 'ws': 'nan', 'ba': 'nan'}  # 'nan', 40
# dd_path_threshold should > ds_threshold

current_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
print("Start time:", current_time)
start_time = time.time()
print(f"{data_set}.graph:")

"""Read data graph"""
data_graph_file = open('data/' + data_set + '/data_graph/' + data_set + '.graph', "r")
data_graph = read_graph(data_graph_file)
data_graph_file.close()
print(f"Data graph has {data_graph['num_v']} nodes, {data_graph['num_e']} edges.")

"""Read query graph"""
query_folder = 'data/' + data_set + '/query_graph/'
query_files = get_files(query_folder)
queries = {}
for query_name in query_files:
    query_graph_file = open(query_folder + query_name, "r")
    query_graph = read_graph(query_graph_file)
    query_graph_file.close()
    queries.update({query_name: query_graph})
print(f"{data_set} data set has {len(queries)} queries.")

"""Building the data graph indexes"""
decompose_start_time1 = time.time()
dd_index_2_p, dd_index_2_n, dd_index_3, dd_index_5, dd_path_num = \
    data_decompose_path(data_graph, ds_threshold[data_set], dd_path_modes[data_set], dd_path_thresholds[data_set])
decompose_end_time1 = time.time()
dd_2_edges = dd_path_num["dd_2_edges"]
dd_3_edges = dd_path_num["dd_3_edges"]
dd_5_edges = dd_path_num["dd_5_edges"]
"""Output dd-index to save memory"""
len_dd_index_2_p, len_dd_index_2_n, len_dd_index_3, len_dd_index_5 = 0, 0, 0, 0
dd_avg_item_match_2_p, dd_avg_item_match_2_n, dd_avg_item_match_3, dd_avg_item_match_5 = 0, 0, 0, 0
if dd_path_modes[data_set] == '2':
    dd_index_file = 'data/' + data_set + '/dense_index_2_p.out'
    output_dd_files(dd_index_file, dd_index_2_p)
    len_dd_index_2_p = len(dd_index_2_p)
    dd_avg_item_match_2_p = statistics_item_dd(dd_index_2_p)
    del dd_index_2_p
    dd_index_file = 'data/' + data_set + '/dense_index_2_n.out'
    output_dd_files(dd_index_file, dd_index_2_n)
    len_dd_index_2_n = len(dd_index_2_n)
    dd_avg_item_match_2_n = statistics_item_dd(dd_index_2_n)
    del dd_index_2_n
else:
    dd_index_file = 'data/' + data_set + '/dense_index_3.out'
    output_dd_files(dd_index_file, dd_index_3)
    len_dd_index_3 = len(dd_index_3)
    dd_avg_item_match_3 = statistics_item_dd(dd_index_3)
    del dd_index_3

    len_dd_index_5, dd_avg_item_match_5 = 0, 0
    if dd_path_thresholds[data_set] != 'nan':
        dd_index_file = 'data/' + data_set + '/dense_index_5.out'
        output_dd_files(dd_index_file, dd_index_5)
        len_dd_index_5 = len(dd_index_5)
        dd_avg_item_match_5 = statistics_item_dd(dd_index_5)
        del dd_index_5

decompose_start_time2 = time.time()
sparse_ags_no_emb, sparse_node_num = data_decompose_graph(data_graph, ds_threshold[data_set])
decompose_end_time2 = time.time()
if dd_path_modes[data_set] == '2':
    print(f"Data graph has sparse nodes {sparse_node_num} and dd-2 edges {dd_2_edges}.")
    contain_sparse_edges = 2 * (data_graph['num_e'] - dd_2_edges)
    cse_ratio = contain_sparse_edges / (2 * data_graph['num_e']) * 100
    dd_2_ratio = dd_2_edges / data_graph['num_e'] * 100
    print(f"Data graph has contain-sparse edges {cse_ratio}% and dd-2 edges {dd_2_ratio}%.")
elif dd_path_modes[data_set] != '2' and dd_path_thresholds[data_set] == 'nan':
    print(f"Data graph has sparse nodes {sparse_node_num} and dd-3 edges {dd_3_edges}.")
    contain_sparse_edges = 2 * (data_graph['num_e'] - dd_3_edges)
    cse_ratio = contain_sparse_edges / (2 * data_graph['num_e']) * 100
    dd_3_ratio = dd_3_edges / data_graph['num_e'] * 100
    print(f"Data graph has contain-sparse edges {cse_ratio}% and dd-3 edges {dd_3_ratio}%.")
elif dd_path_modes[data_set] != '2' and dd_path_thresholds[data_set] != 'nan':
    print(f"Data graph has sparse nodes {sparse_node_num}, dd-3 edges {dd_3_edges} and dd-5 edges {dd_5_edges}.")
    contain_sparse_edges = 2 * (data_graph['num_e'] - dd_3_edges - dd_5_edges)
    cse_ratio = contain_sparse_edges / (2 * data_graph['num_e']) * 100
    dd_3_ratio = dd_3_edges / data_graph['num_e'] * 100
    dd_5_ratio = dd_5_edges / data_graph['num_e'] * 100
    print(f"Data graph has contain-sparse edges {cse_ratio}%, dd-3 edges {dd_3_ratio}% and dd-5 edges {dd_5_ratio}%.")
print("Index: Positive & Negative sparse index without embedding and Dense-Dense index complete.")

"""Extract anchor-edge structure in query growth"""
for key in queries:
    graph_dfs(queries[key])
    anchor_structures_extract(queries[key], dd_path_modes[data_set], dd_path_thresholds[data_set])
print("Queries: DFS edges, Non-DFS edges & DFS anchor structures complete.")

"""Statistics the data graph indexes (before embedding and merge)"""
sparse_ags_num = statistics_sparse_ags(sparse_ags_no_emb)
paths_before_merge_2_p = dd_path_num["paths_before_merge_2_p"]
paths_before_merge_2_n = dd_path_num["paths_before_merge_2_n"]
paths_before_merge_2 = paths_before_merge_2_p + paths_before_merge_2_n
paths_before_merge_3 = dd_path_num["paths_before_merge_3"]
paths_before_merge_5 = dd_path_num["paths_before_merge_5"]
paths_before_merge_35 = paths_before_merge_3 + paths_before_merge_5
decompose_time = (decompose_end_time1 - decompose_start_time1) + (decompose_end_time2 - decompose_start_time2)
print("-" * 89)
print("Index: before embedding and merge:")
print(f"Number of sparse anchor graphs in positive & negative sparse index is {sparse_ags_num}.")
if dd_path_modes[data_set] == '2':
    print(f"Number of paths in dense-dense-2-p index is {paths_before_merge_2_p}.")
    print(f"Number of paths in dense-dense-2-n index is {paths_before_merge_2_n}.")
    print(f"Number of paths in all dense-dense index is {paths_before_merge_2}.")
else:
    print(f"Number of paths in dense-dense-3 index is {paths_before_merge_3}.")
    if dd_path_thresholds[data_set] != 'nan':
        print(f"Number of paths in dense-dense-5 index is {paths_before_merge_5}.")
    print(f"Number of paths in all dense-dense index is {paths_before_merge_35}.")
print(f"Build time of the index without embedding and merging about: {decompose_time} s.")
print("-" * 89)

"""GNN params"""
with open("gnn_params.json") as f:
    gnn_config = json.load(f)
gnn_device = gpu_setup(gnn_config[gnn_model_name]['gpu']['use'], gnn_config[gnn_model_name]['gpu']['id'])
gnn_params = gnn_config[gnn_model_name]['params']
gnn_net_params = gnn_config[gnn_model_name]['net_params']
gnn_net_params['device'] = gnn_device
gnn_net_params['node_label_types'] = len(set(data_graph['node_labels'])) + 20
gnn_net_params['gpu_id'] = gnn_config[gnn_model_name]['gpu']['id']
gnn_net_params['emb_dimension'] = emb_dimension
gnn_batch_size = gnn_config[gnn_model_name]['params']['batch_size']
print("GNN params complete.")

"""Prepare data for GNN"""
start_time_tmp2 = time.time()
index_sparse_ags, index_key_ids = data_set_prepare(sparse_ags_no_emb)
query_p_ags, query_n_ags, query_substructure_key_ids = query_set_prepare(queries)
end_time_tmp2 = time.time()
print(f"Time of set_prepare in prepare_gnn_data function: {end_time_tmp2 - start_time_tmp2} s.")

"""Prepare data_loader for GNN and training"""
gnn_sparse_lp = {}
gnn_start_time, gnn_end_time = 0, 0
if len(index_sparse_ags) > 0:
    start_time_tmp3 = time.time()
    sparse_data_loader = prepare_gnn_sparse(index_sparse_ags, query_p_ags, query_n_ags, gnn_batch_size)
    del index_sparse_ags, query_p_ags, query_n_ags
    end_time_tmp3 = time.time()
    print(f"Time of preparing sparse_data_loader: {end_time_tmp3 - start_time_tmp3} s.")

    """Achieve embeddings for ss-index and query"""
    gnn_start_time = time.time()
    gnn_sparse_lp = train_test_pipeline(data_set, gnn_model_name, gnn_params, gnn_net_params, sparse_data_loader)
    gnn_end_time = time.time()
    del sparse_data_loader
    print("Achieve embeddings for sparse anchor graphs and query complete.")
    print('-' * 89)

"""Attach embeddings into index and query"""
attach_emb_index(index_key_ids, gnn_sparse_lp, sparse_ags_no_emb, emb_precision)
attach_emb_query(query_substructure_key_ids, gnn_sparse_lp, queries, emb_precision)
print("Attach embeddings into index and query complete.")

"""Merge isomorphic index entries"""
current_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
print("Current time:", current_time)
index_start_time = time.time()
sparse_index = merge_sparse_index(sparse_ags_no_emb)
index_end_time = time.time()
print("Merge isomorphic index entries complete.")
current_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
print("Current time:", current_time)
del sparse_ags_no_emb

"""Output the data graph indexes (after embedding and merge) and anchor-edge embeddings for each query"""
print("-" * 89)
len_dd_index_2 = len_dd_index_2_p + len_dd_index_2_n
len_dd_index_35 = len_dd_index_3 + len_dd_index_5
print("Index: after embedding and merge:")
print(f"Number of sparse anchor graphs in positive & negative sparse index is {len(sparse_index)}.")
if dd_path_modes[data_set] == '2':
    print(f"Number of paths in dense-dense-2-p index is {len_dd_index_2_p}.")
    print(f"Number of paths in dense-dense-2-n index is {len_dd_index_2_n}.")
    print(f"Number of paths in all dense-dense index is {len_dd_index_2}.")
else:
    print(f"Number of paths in dense-dense-3 index is {len_dd_index_3}.")
    if dd_path_thresholds[data_set] != 'nan':
        print(f"Number of paths in dense-dense-5 index is {len_dd_index_5}.")
    print(f"Number of paths in all dense-dense index is {len_dd_index_35}.")
print("-" * 89)

p_avg_item_match, n_avg_item_match = statistics_item_sparse(sparse_index)
print("Index: average candidate matches in each item:")
print(f"Average candidate matches of positive item in positive-sparse index is {p_avg_item_match}.")
print(f"Average candidate matches of negative item in negative-sparse index is {n_avg_item_match}.")
if dd_path_modes[data_set] == '2':
    print(f"Average candidate matches in dense-dense-2-p index is {dd_avg_item_match_2_p}.")
    print(f"Average candidate matches in dense-dense-2-n index is {dd_avg_item_match_2_n}.")
else:
    print(f"Average candidate matches in dense-dense-3 index is {dd_avg_item_match_3}.")
    if dd_path_thresholds[data_set] != 'nan':
        print(f"Average candidate matches in dense-dense-5 index is {dd_avg_item_match_5}.")
print("-" * 89)

sparse_index_file = 'data/' + data_set + '/sparse_index.out'
output_index_files(sparse_index_file, sparse_index)
query_out_path = 'data/' + data_set + "/query_graph_emb/"
if not os.path.exists(query_out_path):
    os.mkdir(query_out_path)
output_query_emb_file(query_out_path, queries, dd_path_thresholds[data_set])
print("Output the data graph indexes and anchor-edge embeddings for each query complete.")

print(f"Graph decompose and structures mining time of {data_set}: {decompose_time} s.")
gnn_training_time = gnn_end_time - gnn_start_time
print(f"GNN training time of {data_set}: {gnn_training_time} s.")
index_construct_time = index_end_time - index_start_time
print(f"Index construct time of {data_set}: {index_construct_time} s.")

end_time = time.time()
print(f"Total time of {data_set}: {end_time - start_time} s.")

print('*' * 89)
print('*' * 89)
current_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
print("End time:", current_time)
