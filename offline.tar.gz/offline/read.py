import os


def get_files(folder):
    files = []
    for file in os.listdir(folder):
        if os.path.isfile(os.path.join(folder, file)):
            files.append(file)
    return files


def read_line(input_file):
    line = input_file.readline()
    if line != "":
        data = line.strip('\n').split('/n')
        str_list = data[0].split(' ')
    else:
        return "finish"
    return str_list


def read_graph(input_file):
    nodes, node_labels, degrees, from_nodes, to_nodes, edges = [], [], [], [], [], []
    graph, node_neighbors = {}, {}
    str_list = read_line(input_file)
    while str_list[0] == 't':
        graph.update({'num_v': int(str_list[1])})
        graph.update({'num_e': int(str_list[2])})
        str_list = read_line(input_file)
    while str_list[0] == 'v':
        node_id = int(str_list[1])
        nodes.append(node_id)
        node_labels.append(int(str_list[2]))
        degrees.append(int(str_list[3]))
        node_neighbors.update({node_id: []})
        str_list = read_line(input_file)
    graph.update({'nodes': nodes, 'node_labels': node_labels, 'degrees': degrees})
    while str_list[0] == 'e':
        from_node = int(str_list[1])
        to_node = int(str_list[2])
        from_nodes.append(from_node)
        to_nodes.append(to_node)
        edges.append([from_node, to_node])
        node_neighbors[from_node].append(to_node)
        node_neighbors[to_node].append(from_node)
        str_list = read_line(input_file)
    graph.update({'from_nodes': from_nodes, 'to_nodes': to_nodes,
                  'edges': edges, 'node_neighbors': node_neighbors})

    return graph


# def read_graph(input_file):
#     nodes, node_labels, degrees, from_nodes, to_nodes, edges = [], [], [], [], [], []
#     graph, node_neighbors = {}, {}
#     str_list = read_line(input_file)
#     while str_list[0] == 't':
#         graph.update({'num_v': int(str_list[1])})
#         graph.update({'num_e': int(str_list[2])})
#         str_list = read_line(input_file)
#     while str_list[0] == 'v':
#         node_id = int(str_list[1])
#         nodes.append(node_id)
#         node_labels.append(int(str_list[2]))
#         # degrees.append(int(str_list[3]))
#         node_neighbors.update({node_id: []})
#         str_list = read_line(input_file)
#     graph.update({'nodes': nodes, 'node_labels': node_labels})
#     while str_list[0] == 'e':
#         from_node = int(str_list[1])
#         to_node = int(str_list[2])
#         from_nodes.append(from_node)
#         to_nodes.append(to_node)
#         edges.append([from_node, to_node])
#         node_neighbors[from_node].append(to_node)
#         node_neighbors[to_node].append(from_node)
#         str_list = read_line(input_file)
#     graph.update({'from_nodes': from_nodes, 'to_nodes': to_nodes,
#                   'edges': edges, 'node_neighbors': node_neighbors})
#     degrees = [0] * len(nodes)
#     for node_id in node_neighbors:
#         degrees[node_id] = len(node_neighbors[node_id])
#     graph.update({'degrees': degrees})
#
#     return graph
