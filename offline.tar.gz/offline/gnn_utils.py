import os
import dgl
import torch
import numpy as np
import torch.utils.data
import torch.nn.functional as F
from torch.utils.data import DataLoader

torch.set_printoptions(precision=6)
EPS = 1e-5


def gpu_setup(use_gpu, gpu_id):
    os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"
    os.environ["CUDA_VISIBLE_DEVICES"] = str(gpu_id)

    if torch.cuda.is_available() and use_gpu:
        print('cuda available with GPU:', torch.cuda.get_device_name(0))
        device = torch.device("cuda")
    else:
        print('cuda not available.')
        device = torch.device("cpu")
    return device


class GraphDGL(torch.utils.data.Dataset):
    def __init__(self, graphs, num_graphs):
        self.graphs = graphs
        self.num_graphs = num_graphs
        self.graph_lists = []
        self.graph_labels = []
        self.n_samples = len(self.graphs)
        self._prepare()

    def _prepare(self):
        for graph in self.graphs:
            node_features = graph['node_labels'].long()
            adj = graph['adj']
            edge_list = (adj != 0).nonzero(as_tuple=False)
            edge_idx_in_adj = edge_list.split(1, dim=1)
            edge_features = adj[edge_idx_in_adj].reshape(-1).long()

            # Create the DGL Graph
            g = dgl.DGLGraph()
            g.add_nodes(graph['num_v'])
            g.ndata['feat'] = node_features

            for src, dst in edge_list:
                g.add_edges(src.item(), dst.item())
            g.edata['feat'] = edge_features

            self.graph_lists.append(g)
            self.graph_labels.append(graph['unique_label'])

    def __len__(self):
        return self.n_samples

    def __getitem__(self, idx):
        return self.graph_lists[idx], self.graph_labels[idx]


def collate(samples):
    graphs, labels = map(list, zip(*samples))
    labels = torch.tensor(np.array(labels)).unsqueeze(1)
    batched_graph = dgl.batch(graphs)

    return batched_graph, labels


def data_set_prepare(sparse_ags_no_emb):
    sparse_anchor_graphs, ds_key_ids = [], []
    for node in sparse_ags_no_emb:
        anchor_graphs = sparse_ags_no_emb[node]
        for i in range(len(anchor_graphs)):
            sparse_anchor_graphs.append(anchor_graphs[i])
            ds_key_ids.append([node, i])

    return sparse_anchor_graphs, ds_key_ids


def query_set_prepare(queries):
    p_anchor_graphs, n_anchor_graphs, graph_key_ids = [], [], []
    for key in queries:
        anchor_structures = queries[key]['anchor_structures']
        for dfs_edge in queries[key]['dfs_edges']:
            dfs_edge_key = str(dfs_edge[0]) + '-' + str(dfs_edge[1])
            structures = anchor_structures[dfs_edge_key]
            p_anchor_graph = structures['p_anchor_graph']
            n_anchor_graph = structures['n_anchor_graph']
            p_anchor_graphs.append(p_anchor_graph)
            n_anchor_graphs.append(n_anchor_graph)
            graph_key_ids.append([key, dfs_edge_key])

        for no_dfs_edge in queries[key]['no_dfs_edges']:
            no_dfs_edge_key = str(no_dfs_edge[0]) + '-' + str(no_dfs_edge[1])
            structures = anchor_structures[no_dfs_edge_key]
            p_anchor_graph = structures['p_anchor_graph']
            n_anchor_graph = structures['n_anchor_graph']
            p_anchor_graphs.append(p_anchor_graph)
            n_anchor_graphs.append(n_anchor_graph)
            graph_key_ids.append([key, no_dfs_edge_key])

    return p_anchor_graphs, n_anchor_graphs, graph_key_ids


def data_format(graphs):
    format_data = []
    for i in range(len(graphs)):
        unique_label = torch.tensor(float(i))
        node_labels = torch.tensor(graphs[i]['node_labels'], dtype=torch.int16)
        adj = torch.tensor(graphs[i]['adj'], dtype=torch.int16)
        format_graph = {'num_v': graphs[i]['num_v'], 'node_labels': node_labels,
                        'adj': adj, 'unique_label': unique_label}
        format_data.append(format_graph)

    return format_data


def data_loader(graphs, batch_size, shuffle):
    format_data = data_format(graphs)
    dgl_data = GraphDGL(format_data, num_graphs=len(format_data))
    loader_data = DataLoader(dgl_data, batch_size=batch_size, shuffle=shuffle, drop_last=False, collate_fn=collate)
    del format_data, dgl_data

    return loader_data


def MAE(scores, targets):
    mae = F.l1_loss(scores, targets)
    mae = mae.detach().item()

    return mae


def prepare_gnn_sparse(index_sparse_ags, query_p_ags, query_n_ags, gnn_batch_size):
    index_sparse_train_loader = data_loader(index_sparse_ags, gnn_batch_size, False)
    query_p_test_loader = data_loader(query_p_ags, gnn_batch_size, False)
    query_n_test_loader = data_loader(query_n_ags, gnn_batch_size, False)
    sparse_data_loader = {'index_train': index_sparse_train_loader, 'index_test': index_sparse_train_loader,
                          'query_p_test': query_p_test_loader, 'query_n_test': query_n_test_loader}

    return sparse_data_loader
