import os
import time
import torch
import random
import numpy as np
from tqdm import tqdm
from torch import optim
from gnn_utils import MAE
from gnn_net import gnn_model


def train_epoch(model, optimizer, device, data_loader):
    model.train()
    epoch_loss, epoch_train_mae, nb_data, i = 0, 0, 0, 0
    for i, (batch_graphs, batch_targets) in enumerate(data_loader):
        batch_graphs = batch_graphs.to(device)
        batch_x = batch_graphs.ndata['feat'].to(device)  # num x feat
        batch_targets = batch_targets.to(device)
        optimizer.zero_grad()
        batch_scores, _ = model.forward(batch_graphs, batch_x)
        loss = model.loss(batch_scores, batch_targets)
        loss.backward()
        optimizer.step()
        epoch_loss += loss.detach().item()
        epoch_train_mae += MAE(batch_scores, batch_targets)
        nb_data += batch_targets.size(0)
    epoch_loss /= (i + 1)
    epoch_train_mae /= (i + 1)

    return epoch_loss, epoch_train_mae, optimizer


def test_epoch(model, device, data_loader):
    model.eval()
    nb_data = 0
    label_predict = []
    with torch.no_grad():
        for i, (batch_graphs, batch_targets) in enumerate(data_loader):
            batch_graphs = batch_graphs.to(device)
            batch_x = batch_graphs.ndata['feat'].to(device)
            batch_targets = batch_targets.to(device)
            batch_scores, batch_score_over_layer = model.forward(batch_graphs, batch_x)
            for j in range(batch_score_over_layer.shape[0]):
                label_predict.append(batch_score_over_layer[j].cpu().tolist())
            nb_data += batch_targets.size(0)

    return label_predict


def train_test_pipeline(data_set_name, gnn_model_name, gnn_params, gnn_net_params, data_loader):
    t0 = time.time()
    per_epoch_time = []
    model_type = "sparse"

    if not os.path.exists('./model_save/'):
        os.makedirs('./model_save/')
    device = gnn_net_params['device']

    # setting seeds
    random.seed(gnn_params['seed'])
    np.random.seed(gnn_params['seed'])
    torch.manual_seed(gnn_params['seed'])
    if device.type == 'cuda':
        torch.cuda.manual_seed(gnn_params['seed'])

    model = gnn_model(gnn_model_name, gnn_net_params)
    model = model.to(device)

    model_parameters = {}
    for name, parameters in model.named_parameters():
        model_parameters[name] = parameters.size()
    file_path = f'./model_save/{data_set_name}_{gnn_model_name}_{model_type}_arch.txt'
    file = open(file_path, 'w')
    file.write(str(model_parameters))
    file.close()

    optimizer = optim.Adam(model.parameters(), lr=gnn_params['init_lr'], weight_decay=gnn_params['weight_decay'])
    scheduler = optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', factor=gnn_params['lr_reduce_factor'],
                                                     patience=gnn_params['lr_schedule_patience'], verbose=True)

    # At any point you can hit Ctrl + C to break out of training early.
    try:
        print(f"{gnn_model_name}-{model_type} training......")
        with tqdm(range(gnn_params['epochs'])) as t:
            for epoch in t:
                t.set_description('Epoch %d' % epoch)
                start = time.time()
                epoch_train_loss, epoch_train_mae, optimizer \
                    = train_epoch(model, optimizer, device, data_loader['index_train'])

                t.set_postfix(time=time.time() - start, lr=optimizer.param_groups[0]['lr'],
                              train_loss=epoch_train_loss, train_mae=epoch_train_mae)

                per_epoch_time.append(time.time() - start)

                scheduler.step(epoch_train_loss)

                if optimizer.param_groups[0]['lr'] < gnn_params['min_lr']:
                    print("\n!! LR EQUAL TO MIN LR SET.")
                    break

                # Stop training after gat_msa_params['max_time'] hours
                if time.time() - t0 > gnn_params['max_time'] * 3600:
                    print('-' * 89)
                    print("Max_time for training elapsed {:.2f} hours, so stopping".format(gnn_params['max_time']))
                    break
        print(f"{gnn_model_name}-{model_type}-Convergence Time (Epochs): " + "{:.4f}".format(epoch))
        print(f"{gnn_model_name}-{model_type}-AVG TIME PER EPOCH: " + "{:.4f}s".format(np.mean(per_epoch_time)))

    except KeyboardInterrupt:
        print('Exiting from training early because of KeyboardInterrupt')

    index_test_lp = test_epoch(model, device, data_loader['index_test'])
    query_p_test_lp = test_epoch(model, device, data_loader['query_p_test'])
    query_n_test_lp = test_epoch(model, device, data_loader['query_n_test'])
    gnn_data_lp = {'index_test': index_test_lp, 'query_p_test': query_p_test_lp, 'query_n_test': query_n_test_lp}

    torch.save(model.state_dict(), f'./model_save/{data_set_name}_{gnn_model_name}_{model_type}_para.pkl')
    model_params_end = torch.load(open(f'./model_save/{data_set_name}_{gnn_model_name}_{model_type}_para.pkl', 'rb'))
    torch.set_printoptions(threshold=20000)
    file = open(f'./model_save/{data_set_name}_{gnn_model_name}_{model_type}_para.txt', 'w')
    file.write(str(model_params_end))
    file.close()

    return gnn_data_lp
