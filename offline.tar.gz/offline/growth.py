from index import *


def dfs(graph_neighbors, node, visited, edges):
    visited[node] = True
    for neighbor in graph_neighbors[node]:
        if not visited[neighbor]:
            edges.append([node, neighbor])
            dfs(graph_neighbors, neighbor, visited, edges)

    return edges


def graph_dfs(graph):
    dfs_edges = []
    graph_sorted_neighbors = {}
    degrees = graph['degrees']
    for key in graph['node_neighbors']:
        node_neighbors = graph['node_neighbors'][key]
        zip_list = list(zip(node_neighbors, [degrees[node] for node in node_neighbors]))
        sorted_zip_list = sorted(zip_list, key=lambda x: x[1], reverse=True)
        sorted_neighbors, _ = [list(x) for x in zip(*sorted_zip_list)]
        graph_sorted_neighbors.update({key: sorted_neighbors})

    max_degree_node = degrees.index(max(degrees))
    visited_nodes = {node: False for node in graph_sorted_neighbors}
    dfs_edges = dfs(graph_sorted_neighbors, max_degree_node, visited_nodes, dfs_edges)
    dfs_nodes = [dfs_edges[0][0]]
    for i in range(len(dfs_edges)):
        dfs_nodes.append(dfs_edges[i][1])

    no_dfs_edges = []
    no_dfs_edges_dict = {}
    for edge in graph['edges']:
        if edge not in dfs_edges and [edge[1], edge[0]] not in dfs_edges:
            if dfs_nodes.index(edge[0]) <= dfs_nodes.index(edge[1]):
                no_dfs_edges.append([edge[0], edge[1]])
                if edge[1] in no_dfs_edges_dict:
                    no_dfs_edges_dict[edge[1]].append(edge[0])
                else:
                    no_dfs_edges_dict.update({edge[1]: [edge[0]]})
            else:
                no_dfs_edges.append([edge[1], edge[0]])
                if edge[0] in no_dfs_edges_dict:
                    no_dfs_edges_dict[edge[0]].append(edge[1])
                else:
                    no_dfs_edges_dict.update({edge[0]: [edge[1]]})

    graph.update({'dfs_edges': dfs_edges, 'dfs_nodes': dfs_nodes, 'no_dfs_edges': no_dfs_edges,
                  'no_dfs_edges_dict': no_dfs_edges_dict})


def query_sparse_sparse(graph, edge):
    # original sparse-sparse graph structure
    from_nodes, to_nodes = [], []
    neighbors_0 = graph['node_neighbors'][edge[0]]
    neighbors_1 = graph['node_neighbors'][edge[1]]
    nodes = list(set(neighbors_0 + neighbors_1))
    node_labels = [graph['node_labels'][node_id] for node_id in nodes]
    node_noa_neighbors = {edge[0]: [node for node in neighbors_0 if node != edge[1]],
                          edge[1]: [node for node in neighbors_1 if node != edge[0]]}  # node_no_anchor_neighbors
    for node in neighbors_0:
        from_nodes.append(edge[0])
        to_nodes.append(node)
    for node in neighbors_1:
        if node != edge[0]:
            from_nodes.append(edge[1])
            to_nodes.append(node)

    ss_graph = {'nodes': nodes, 'node_labels': node_labels, 'from_nodes': from_nodes, 'to_nodes': to_nodes}

    return ss_graph


def ss_anchor_graph_extract(graph, anchor_edge):
    anchor_edge_labels = [graph['node_labels'][node_id] for node_id in anchor_edge]
    neighbors = graph['node_neighbors'][anchor_edge[0]]

    nodes = list(set([anchor_edge[0], anchor_edge[1]] + neighbors))
    node_labels = [graph['node_labels'][node_id] for node_id in nodes]
    from_nodes, to_nodes = [anchor_edge[0]], [anchor_edge[1]]
    for neighbor in neighbors:
        if neighbor != anchor_edge[1]:
            from_nodes.append(anchor_edge[0])
            to_nodes.append(neighbor)
    anchor_graph = {'nodes': nodes, 'node_labels': node_labels, 'from_nodes': from_nodes,
                    'to_nodes': to_nodes, 'anchor_edge': anchor_edge, 'anchor_edge_labels': anchor_edge_labels}
    # anchor_edge = [anchor_end_node, anchor_node], anchor_edge_labels = [anchor_end_node_label, anchor_node_label]

    return anchor_graph


def p_anchor_graph_extract(graph, anchor_edge):
    anchor_edge_labels = [graph['node_labels'][node_id] for node_id in anchor_edge]
    neighbors = graph['node_neighbors'][anchor_edge[0]]

    nodes = list(set([anchor_edge[0], anchor_edge[1]] + neighbors))
    node_labels = [graph['node_labels'][node_id] for node_id in nodes]
    from_nodes, to_nodes = [anchor_edge[0]], [anchor_edge[1]]
    for neighbor in neighbors:
        if neighbor != anchor_edge[1]:
            from_nodes.append(anchor_edge[0])
            to_nodes.append(neighbor)
    p_anchor_graph = {'nodes': nodes, 'node_labels': node_labels, 'from_nodes': from_nodes,
                      'to_nodes': to_nodes, 'anchor_edge': anchor_edge, 'anchor_edge_labels': anchor_edge_labels}
    # anchor_edge = [anchor_end_node, anchor_node], anchor_edge_labels = [anchor_end_node_label, anchor_node_label]

    return p_anchor_graph


def n_anchor_graph_extract(graph, anchor_edge):
    anchor_edge_labels = [graph['node_labels'][node_id] for node_id in anchor_edge]
    neighbors = graph['node_neighbors'][anchor_edge[1]]

    nodes = list(set([anchor_edge[0], anchor_edge[1]] + neighbors))
    node_labels = [graph['node_labels'][node_id] for node_id in nodes]
    from_nodes, to_nodes = [anchor_edge[0]], [anchor_edge[1]]
    for neighbor in neighbors:
        if neighbor != anchor_edge[0]:
            from_nodes.append(anchor_edge[1])
            to_nodes.append(neighbor)
    n_anchor_graph = {'nodes': nodes, 'node_labels': node_labels, 'from_nodes': from_nodes,
                      'to_nodes': to_nodes, 'anchor_edge': anchor_edge, 'anchor_edge_labels': anchor_edge_labels}
    # anchor_edge = [anchor_end_node, anchor_node], anchor_edge_labels = [anchor_end_node_label, anchor_node_label]

    return n_anchor_graph


def dd_2_path_extract(graph, anchor_edge):
    node_labels = graph['node_labels']
    node_neighbors = graph['node_neighbors']
    noa_neighbors_0 = node_neighbors[anchor_edge[0]].copy()
    noa_neighbors_0.remove(anchor_edge[1])
    noa_neighbors_1 = node_neighbors[anchor_edge[1]].copy()
    noa_neighbors_1.remove(anchor_edge[0])

    dd_paths_p_emb, anchor_edges_p, dd_paths_n_emb, anchor_edges_n = [], [], [], []
    label_0 = node_labels[anchor_edge[0]]
    label_1 = node_labels[anchor_edge[1]]
    if len(noa_neighbors_0) == 0:
        path_emb_p = str(-1) + '-' + str(label_0) + '-' + str(label_1)
        dd_paths_p_emb.append(path_emb_p)
        anchor_edges_p.append(anchor_edge)
    else:
        for i in range(len(noa_neighbors_0)):
            noa_neighbor_0 = noa_neighbors_0[i]
            path_emb_p = str(node_labels[noa_neighbor_0]) + '-' + str(label_0) + '-' + str(label_1)
            dd_paths_p_emb.append(path_emb_p)
            anchor_edges_p.append(anchor_edge)
    if len(noa_neighbors_1) == 0:
        path_emb_n = str(label_0) + '-' + str(label_1) + '-' + str(-1)
        dd_paths_n_emb.append(path_emb_n)
        anchor_edges_n.append(anchor_edge)
    else:
        for i in range(len(noa_neighbors_1)):
            noa_neighbor_1 = noa_neighbors_1[i]
            path_emb_n = str(label_0) + '-' + str(label_1) + '-' + str(node_labels[noa_neighbor_1])
            dd_paths_n_emb.append(path_emb_n)
            anchor_edges_n.append(anchor_edge)

    return dd_paths_p_emb, anchor_edges_p, dd_paths_n_emb, anchor_edges_n


def dd_3_path_extract(graph, anchor_edge):
    node_labels = graph['node_labels']
    node_neighbors = graph['node_neighbors']
    noa_neighbors_0 = node_neighbors[anchor_edge[0]].copy()
    noa_neighbors_0.remove(anchor_edge[1])
    noa_neighbors_1 = node_neighbors[anchor_edge[1]].copy()
    noa_neighbors_1.remove(anchor_edge[0])

    dd_paths_emb, anchor_edges = [], []
    label_0 = node_labels[anchor_edge[0]]
    label_1 = node_labels[anchor_edge[1]]
    if len(noa_neighbors_0) == 0 and len(noa_neighbors_1) == 0:
        path_emb = str(-1) + '-' + str(label_0) + '-' + str(label_1) + '-' + str(-1)
        dd_paths_emb.append(path_emb)
        anchor_edges.append(anchor_edge)
    elif len(noa_neighbors_0) == 0 and len(noa_neighbors_1) != 0:
        for i in range(len(noa_neighbors_1)):
            noa_neighbor_1 = noa_neighbors_1[i]
            path_emb = str(-1) + '-' + str(label_0) + '-' + str(label_1) + '-' + str(node_labels[noa_neighbor_1])
            dd_paths_emb.append(path_emb)
            anchor_edges.append(anchor_edge)
            # (edge[0], edge[1], neighbors_1[j]) form a path with 3 length
    elif len(noa_neighbors_0) != 0 and len(noa_neighbors_1) == 0:
        for i in range(len(noa_neighbors_0)):
            noa_neighbor_0 = noa_neighbors_0[i]
            path_emb = str(node_labels[noa_neighbor_0]) + '-' + str(label_0) + '-' + str(label_1) + '-' + str(-1)
            dd_paths_emb.append(path_emb)
            anchor_edges.append(anchor_edge)
    else:
        for i in range(len(noa_neighbors_0)):
            for j in range(len(noa_neighbors_1)):
                noa_neighbor_0 = noa_neighbors_0[i]
                noa_neighbor_1 = noa_neighbors_1[j]
                if noa_neighbor_0 != noa_neighbor_1:
                    path_emb = str(node_labels[noa_neighbor_0]) + '-' + str(label_0) + '-' + str(label_1) + '-' + \
                               str(node_labels[noa_neighbor_1])
                else:
                    path_emb = str(-2) + '-' + str(label_0) + '-' + str(label_1) + '-' + str(
                        node_labels[noa_neighbor_1])
                    # (edge[0], edge[1], neighbors_1[j]) form a triangle
                dd_paths_emb.append(path_emb)
                anchor_edges.append(anchor_edge)

    return dd_paths_emb, anchor_edges


def dd_5_path_extract(graph, anchor_edge):
    node_labels = graph['node_labels']
    node_neighbors = graph['node_neighbors']
    noa_neighbors_0 = node_neighbors[anchor_edge[0]].copy()
    noa_neighbors_0.remove(anchor_edge[1])
    noa_neighbors_1 = node_neighbors[anchor_edge[1]].copy()
    noa_neighbors_1.remove(anchor_edge[0])
    noa_neighbors_0_hop, noa_neighbors_1_hop = {}, {}
    for noa_neighbor in noa_neighbors_0:
        hop_neighbors = node_neighbors[noa_neighbor].copy()
        hop_neighbors.remove(anchor_edge[0])
        noa_neighbors_0_hop.update({noa_neighbor: hop_neighbors})
    for noa_neighbor in noa_neighbors_1:
        hop_neighbors = node_neighbors[noa_neighbor].copy()
        hop_neighbors.remove(anchor_edge[1])
        noa_neighbors_1_hop.update({noa_neighbor: hop_neighbors})

    dd_paths_emb, anchor_edges = [], []
    label_0 = node_labels[anchor_edge[0]]
    label_1 = node_labels[anchor_edge[1]]
    if len(noa_neighbors_0) == 0 and len(noa_neighbors_1) == 0:
        path_emb = str(-1) + '-' + str(-1) + '-' + str(label_0) + '-' + str(label_1) + '-' + str(-1) + '-' + str(-1)
        dd_paths_emb.append(path_emb)
        anchor_edges.append(anchor_edge)
    elif len(noa_neighbors_0) == 0 and len(noa_neighbors_1) != 0:
        for i in range(len(noa_neighbors_1)):
            noa_neighbor_1 = noa_neighbors_1[i]
            if len(noa_neighbors_1_hop[noa_neighbor_1]) == 0:
                path_emb = str(-1) + '-' + str(-1) + '-' + str(label_0) + '-' + str(label_1) + '-' + \
                           str(node_labels[noa_neighbor_1]) + '-' + str(-1)
                dd_paths_emb.append(path_emb)
                anchor_edges.append(anchor_edge)
            else:
                for node in noa_neighbors_1_hop[noa_neighbor_1]:
                    if node == anchor_edge[0]:
                        path_emb = str(-2) + '-' + str(label_0) + '-' + str(label_1) + '-' + \
                                   str(node_labels[noa_neighbor_1])
                        dd_paths_emb.append(path_emb)
                        anchor_edges.append(anchor_edge)
                    else:
                        path_emb = str(-1) + '-' + str(-1) + '-' + str(label_0) + '-' + str(label_1) + '-' + \
                                   str(node_labels[noa_neighbor_1]) + '-' + str(node_labels[node])
                        dd_paths_emb.append(path_emb)
                        anchor_edges.append(anchor_edge)
    elif len(noa_neighbors_0) != 0 and len(noa_neighbors_1) == 0:
        for i in range(len(noa_neighbors_0)):
            noa_neighbor_0 = noa_neighbors_0[i]
            if len(noa_neighbors_0_hop[noa_neighbor_0]) == 0:
                path_emb = str(-1) + '-' + str(node_labels[noa_neighbor_0]) + '-' + str(label_0) + '-' + str(label_1) \
                           + '-' + str(-1) + '-' + str(-1)
                dd_paths_emb.append(path_emb)
                anchor_edges.append(anchor_edge)
            else:
                for node in noa_neighbors_0_hop[noa_neighbor_0]:
                    if node == anchor_edge[1]:
                        path_emb = str(-2) + '-' + str(label_0) + '-' + str(label_1) + '-' + \
                                   str(node_labels[noa_neighbor_0])
                        dd_paths_emb.append(path_emb)
                        anchor_edges.append(anchor_edge)
                    else:
                        path_emb = str(node_labels[node]) + '-' + str(node_labels[noa_neighbor_0]) + '-' + str(label_0) \
                                   + '-' + str(label_1) + '-' + str(-1) + '-' + str(-1)
                        dd_paths_emb.append(path_emb)
                        anchor_edges.append(anchor_edge)
    else:
        for i in range(len(noa_neighbors_0)):
            for j in range(len(noa_neighbors_1)):
                noa_neighbor_0 = noa_neighbors_0[i]
                noa_neighbor_1 = noa_neighbors_1[j]
                if len(noa_neighbors_0_hop[noa_neighbor_0]) != 0 and len(noa_neighbors_1_hop[noa_neighbor_1]) != 0:
                    for node_0 in noa_neighbors_0_hop[noa_neighbor_0]:
                        for node_1 in noa_neighbors_1_hop[noa_neighbor_1]:
                            original_path = [node_0, noa_neighbor_0, anchor_edge[0], anchor_edge[1], noa_neighbor_1,
                                             node_1]
                            if len(set(original_path)) == 6:
                                path_emb = str(node_labels[node_0]) + '-' + str(node_labels[noa_neighbor_0]) + '-' + \
                                           str(label_0) + '-' + str(label_1) + '-' + str(node_labels[noa_neighbor_1]) \
                                           + '-' + str(node_labels[node_1])
                                dd_paths_emb.append(path_emb)
                                anchor_edges.append(anchor_edge)
                            elif noa_neighbor_0 == noa_neighbor_1 and node_0 == anchor_edge[1] and node_1 == \
                                    anchor_edge[0]:
                                path_emb = str(-2) + '-' + str(label_0) + '-' + str(label_1) + '-' + \
                                           str(node_labels[noa_neighbor_0])
                                dd_paths_emb.append(path_emb)
                                anchor_edges.append(anchor_edge)
                            elif noa_neighbor_0 == noa_neighbor_1 and node_0 == anchor_edge[1] and node_1 != \
                                    anchor_edge[0]:
                                path_emb = str(-3) + '-' + str(label_0) + '-' + str(label_1) + '-' + \
                                           str(node_labels[noa_neighbor_0]) + '-' + str(node_labels[node_1])
                                dd_paths_emb.append(path_emb)
                                anchor_edges.append(anchor_edge)
                            elif noa_neighbor_0 == noa_neighbor_1 and node_0 != anchor_edge[1] and node_1 == \
                                    anchor_edge[0]:
                                path_emb = str(-3) + '-' + str(label_0) + '-' + str(label_1) + '-' + \
                                           str(node_labels[noa_neighbor_0]) + '-' + str(node_labels[node_0])
                                dd_paths_emb.append(path_emb)
                                anchor_edges.append(anchor_edge)
                            elif noa_neighbor_0 == noa_neighbor_1 and node_0 != anchor_edge[1] and node_1 != \
                                    anchor_edge[0] \
                                    and node_0 == node_1:
                                path_emb = str(-3) + '-' + str(label_0) + '-' + str(label_1) + '-' + \
                                           str(node_labels[noa_neighbor_0]) + '-' + str(node_labels[node_0])
                                dd_paths_emb.append(path_emb)
                                anchor_edges.append(anchor_edge)
                            elif noa_neighbor_0 == noa_neighbor_1 and node_0 != anchor_edge[1] and node_1 != \
                                    anchor_edge[0] \
                                    and node_0 != node_1:
                                path_emb = str(-11) + '-' + str(label_0) + '-' + str(label_1) + '-' + \
                                           str(node_labels[noa_neighbor_1]) + '-' + str(node_labels[node_0]) + '-' + \
                                           str(node_labels[node_1])
                                dd_paths_emb.append(path_emb)
                                anchor_edges.append(anchor_edge)
                            elif noa_neighbor_0 != noa_neighbor_1 and node_1 == anchor_edge[0] and node_0 != \
                                    noa_neighbor_1 and node_0 != anchor_edge[1]:
                                path_emb = str(-6) + '-' + str(label_0) + '-' + str(label_1) + '-' + \
                                           str(node_labels[noa_neighbor_0]) + '-' + str(node_labels[node_0]) + '-' + \
                                           str(node_labels[noa_neighbor_1])
                                dd_paths_emb.append(path_emb)
                                anchor_edges.append(anchor_edge)
                            elif noa_neighbor_0 != noa_neighbor_1 and node_0 == anchor_edge[1] and node_1 != \
                                    noa_neighbor_0 and node_1 != anchor_edge[0]:
                                path_emb = str(-6) + '-' + str(label_0) + '-' + str(label_1) + '-' + \
                                           str(node_labels[noa_neighbor_0]) + '-' + str(node_labels[noa_neighbor_1]) + \
                                           '-' + str(node_labels[node_1])
                                dd_paths_emb.append(path_emb)
                                anchor_edges.append(anchor_edge)
                            elif noa_neighbor_0 != noa_neighbor_1 and node_0 == noa_neighbor_1 and node_1 == \
                                    noa_neighbor_0:
                                path_emb = str(-5) + '-' + str(label_0) + '-' + str(label_1) + '-' + \
                                           str(node_labels[noa_neighbor_0]) + '-' + str(node_labels[noa_neighbor_1])
                                dd_paths_emb.append(path_emb)
                                anchor_edges.append(anchor_edge)
                            elif noa_neighbor_0 != noa_neighbor_1 and node_0 == noa_neighbor_1 and node_1 != \
                                    noa_neighbor_0 and node_1 != anchor_edge[0]:
                                path_emb = str(-7) + '-' + str(label_0) + '-' + str(label_1) + '-' + \
                                           str(node_labels[noa_neighbor_0]) + '-' + str(node_labels[noa_neighbor_1]) + \
                                           '-' + str(node_labels[node_1])
                                dd_paths_emb.append(path_emb)
                                anchor_edges.append(anchor_edge)
                            elif noa_neighbor_0 != noa_neighbor_1 and node_1 == noa_neighbor_0 and node_0 != \
                                    noa_neighbor_1 and node_0 != anchor_edge[1]:
                                path_emb = str(-7) + '-' + str(label_0) + '-' + str(label_1) + '-' + \
                                           str(node_labels[noa_neighbor_0]) + '-' + str(node_labels[node_0]) + \
                                           '-' + str(node_labels[noa_neighbor_1])
                                dd_paths_emb.append(path_emb)
                                anchor_edges.append(anchor_edge)
                            elif noa_neighbor_0 != noa_neighbor_1 and node_0 == noa_neighbor_1 and node_1 == \
                                    anchor_edge[0]:
                                path_emb = str(-8) + '-' + str(label_0) + '-' + str(label_1) + '-' + \
                                           str(node_labels[noa_neighbor_0]) + '-' + str(node_labels[noa_neighbor_1])
                                dd_paths_emb.append(path_emb)
                                anchor_edges.append(anchor_edge)
                            elif noa_neighbor_0 != noa_neighbor_1 and node_1 == noa_neighbor_0 and node_0 == \
                                    anchor_edge[1]:
                                path_emb = str(-8) + '-' + str(label_0) + '-' + str(label_1) + '-' + \
                                           str(node_labels[noa_neighbor_0]) + '-' + str(node_labels[noa_neighbor_1])
                                dd_paths_emb.append(path_emb)
                                anchor_edges.append(anchor_edge)
                            elif noa_neighbor_0 != noa_neighbor_1 and node_0 == anchor_edge[1] and node_1 == \
                                    anchor_edge[0]:
                                path_emb = str(-9) + '-' + str(label_0) + '-' + str(label_1) + '-' + \
                                           str(node_labels[noa_neighbor_0]) + '-' + str(node_labels[noa_neighbor_1])
                                dd_paths_emb.append(path_emb)
                                anchor_edges.append(anchor_edge)
                            elif noa_neighbor_0 != noa_neighbor_1 and node_0 == node_1:
                                path_emb = str(-10) + '-' + str(label_0) + '-' + str(label_1) + '-' + \
                                           str(node_labels[noa_neighbor_0]) + '-' + str(node_labels[noa_neighbor_1]) + \
                                           '-' + str(node_labels[node_0])
                                dd_paths_emb.append(path_emb)
                                anchor_edges.append(anchor_edge)
                            else:
                                print("miss case testing 1:", [node_0, noa_neighbor_0, anchor_edge[0], anchor_edge[1],
                                                               noa_neighbor_1, node_1])
                elif len(noa_neighbors_0_hop[noa_neighbor_0]) == 0 and len(noa_neighbors_1_hop[noa_neighbor_1]) == 0 \
                        and noa_neighbor_0 == noa_neighbor_1:
                    path_emb = str(-2) + '-' + str(label_0) + '-' + str(label_1) + '-' + \
                               str(node_labels[noa_neighbor_0])
                    dd_paths_emb.append(path_emb)
                    anchor_edges.append(anchor_edge)
                elif len(noa_neighbors_0_hop[noa_neighbor_0]) == 0 and len(noa_neighbors_1_hop[noa_neighbor_1]) == 0 \
                        and noa_neighbor_0 != noa_neighbor_1:
                    path_emb = str(-1) + '-' + str(node_labels[noa_neighbor_0]) + '-' + str(label_0) + '-' + \
                               str(label_1) + '-' + str(node_labels[noa_neighbor_1]) + '-' + str(-1)
                    dd_paths_emb.append(path_emb)
                    anchor_edges.append(anchor_edge)
                elif len(noa_neighbors_0_hop[noa_neighbor_0]) == 0 and len(noa_neighbors_1_hop[noa_neighbor_1]) != 0:
                    for node_1 in noa_neighbors_1_hop[noa_neighbor_1]:
                        if noa_neighbor_0 == noa_neighbor_1 and node_1 == anchor_edge[0]:
                            path_emb = str(-2) + '-' + str(label_0) + '-' + str(label_1) + '-' + \
                                       str(node_labels[noa_neighbor_0])
                            dd_paths_emb.append(path_emb)
                            anchor_edges.append(anchor_edge)
                        elif noa_neighbor_0 == noa_neighbor_1 and node_1 != anchor_edge[0]:
                            path_emb = str(-3) + '-' + str(label_0) + '-' + str(label_1) + '-' + \
                                       str(node_labels[noa_neighbor_0]) + '-' + str(node_labels[node_1])
                            dd_paths_emb.append(path_emb)
                            anchor_edges.append(anchor_edge)
                        elif noa_neighbor_0 != noa_neighbor_1 and node_1 == anchor_edge[0]:
                            path_emb = str(-4) + '-' + str(label_0) + '-' + str(label_1) + '-' + \
                                       str(node_labels[noa_neighbor_0]) + '-' + str(node_labels[noa_neighbor_1])
                            dd_paths_emb.append(path_emb)
                            anchor_edges.append(anchor_edge)
                        elif noa_neighbor_0 != noa_neighbor_1 and node_1 == noa_neighbor_0:
                            path_emb = str(-5) + '-' + str(label_0) + '-' + str(label_1) + '-' + \
                                       str(node_labels[noa_neighbor_0]) + '-' + str(node_labels[noa_neighbor_1])
                            dd_paths_emb.append(path_emb)
                            anchor_edges.append(anchor_edge)
                        elif noa_neighbor_0 != noa_neighbor_1 and node_1 != anchor_edge[0] and node_1 != noa_neighbor_0:
                            path_emb = str(-1) + '-' + str(node_labels[noa_neighbor_0]) + '-' + str(label_0) + '-' + \
                                       str(label_1) + '-' + str(node_labels[noa_neighbor_1]) + '-' + \
                                       str(node_labels[node_1])
                            dd_paths_emb.append(path_emb)
                            anchor_edges.append(anchor_edge)
                        else:
                            print("miss case testing 2:", [noa_neighbor_0, anchor_edge[0], anchor_edge[1],
                                                           noa_neighbor_1, node_1])
                elif len(noa_neighbors_0_hop[noa_neighbor_0]) != 0 and len(noa_neighbors_1_hop[noa_neighbor_1]) == 0:
                    for node_0 in noa_neighbors_0_hop[noa_neighbor_0]:
                        if noa_neighbor_0 == noa_neighbor_1 and node_0 == anchor_edge[1]:
                            path_emb = str(-2) + '-' + str(label_0) + '-' + str(label_1) + '-' + \
                                       str(node_labels[noa_neighbor_0])
                            dd_paths_emb.append(path_emb)
                            anchor_edges.append(anchor_edge)
                        elif noa_neighbor_0 == noa_neighbor_1 and node_0 != anchor_edge[1]:
                            path_emb = str(-3) + '-' + str(label_0) + '-' + str(label_1) + '-' + \
                                       str(node_labels[noa_neighbor_0]) + '-' + str(node_labels[node_0])
                            dd_paths_emb.append(path_emb)
                            anchor_edges.append(anchor_edge)
                        elif noa_neighbor_0 != noa_neighbor_1 and node_0 == anchor_edge[1]:
                            path_emb = str(-4) + '-' + str(label_0) + '-' + str(label_1) + '-' + \
                                       str(node_labels[noa_neighbor_0]) + '-' + str(node_labels[noa_neighbor_1])
                            dd_paths_emb.append(path_emb)
                            anchor_edges.append(anchor_edge)
                        elif noa_neighbor_0 != noa_neighbor_1 and node_0 == noa_neighbor_1:
                            path_emb = str(-5) + '-' + str(label_0) + '-' + str(label_1) + '-' + \
                                       str(node_labels[noa_neighbor_0]) + '-' + str(node_labels[node_0])
                            dd_paths_emb.append(path_emb)
                            anchor_edges.append(anchor_edge)
                        elif noa_neighbor_0 != noa_neighbor_1 and node_0 != anchor_edge[1] and node_0 != noa_neighbor_1:
                            path_emb = str(node_labels[node_0]) + '-' + str(node_labels[noa_neighbor_0]) + '-' + \
                                       str(label_0) + '-' + str(label_1) + '-' + str(node_labels[noa_neighbor_1]) + \
                                       '-' + str(-1)
                            dd_paths_emb.append(path_emb)
                            anchor_edges.append(anchor_edge)
                        else:
                            print("miss case testing 3:", [node_0, noa_neighbor_0, anchor_edge[0], anchor_edge[1],
                                                           noa_neighbor_1])
                else:
                    print("miss case testing 4", [noa_neighbor_0, anchor_edge[0], anchor_edge[1], noa_neighbor_1])

    return dd_paths_emb, anchor_edges


def dd_path_emb(dd_paths_emb, anchor_edges):
    # path = [-1, edge[0], edge[1], -1]
    # path = [-1, edge[0], edge[1], neighbors_1[j]]
    # path = [neighbors_0[i], edge[0], edge[1], -1]
    # path = [neighbors_0[i], edge[0], edge[1], neighbors_1[j]]
    # path = [-2, edge[0], edge[1], neighbors_1[j]]
    dd_path_with_emb = []
    dd_path_set = {}
    for i in range(len(dd_paths_emb)):
        path_emb = dd_paths_emb[i]
        anchor_edge = anchor_edges[i]
        if path_emb not in dd_path_set:
            dd_path_set.update({path_emb: {'path_emb': path_emb, 'anchor_edge': anchor_edge}})

    for path_emb in dd_path_set:
        dd_path_with_emb.append(dd_path_set[path_emb])

    return dd_path_with_emb


def edge_as_extract(graph, edges, dd_path_mode, dd_path_threshold):
    # anchor_end_node = edges[0]
    # anchor_node = edges[1]
    anchor_structures = {}
    for edge in edges:
        p_anchor_graph = p_anchor_graph_extract(graph, edge)
        p_anchor_graph_new = anchor_graph_mapping(p_anchor_graph)
        p_anchor_graph_new.update({'ae_labels': p_anchor_graph['anchor_edge_labels']})
        del p_anchor_graph

        n_anchor_graph = n_anchor_graph_extract(graph, edge)
        n_anchor_graph_new = anchor_graph_mapping(n_anchor_graph)
        n_anchor_graph_new.update({'ae_labels': n_anchor_graph['anchor_edge_labels']})
        del n_anchor_graph

        dd_paths_with_emb_2_p, dd_paths_with_emb_2_n, dd_paths_with_emb_3, dd_paths_with_emb_5 = [], [], [], []
        if dd_path_mode == '3' or dd_path_mode == '3-5':
            dd_paths_emb_3, anchor_edges_3 = dd_3_path_extract(graph, edge)
            dd_paths_with_emb_3 = dd_path_emb(dd_paths_emb_3, anchor_edges_3)
            del dd_paths_emb_3, anchor_edges_3
            if dd_path_threshold != 'nan':
                dd_paths_emb_5, anchor_edges_5 = dd_5_path_extract(graph, edge)
                dd_paths_with_emb_5 = dd_path_emb(dd_paths_emb_5, anchor_edges_5)
                del dd_paths_emb_5, anchor_edges_5
        else:
            dd_paths_emb_2_p, anchor_edges_2_p, dd_paths_emb_2_n, anchor_edges_2_n = dd_2_path_extract(graph, edge)
            dd_paths_with_emb_2_p = dd_path_emb(dd_paths_emb_2_p, anchor_edges_2_p)
            dd_paths_with_emb_2_n = dd_path_emb(dd_paths_emb_2_n, anchor_edges_2_n)
            del dd_paths_emb_2_p, anchor_edges_2_p, dd_paths_emb_2_n, anchor_edges_2_n

        structures = {'p_anchor_graph': p_anchor_graph_new, 'n_anchor_graph': n_anchor_graph_new,
                      'dd_paths_with_emb_2_p': dd_paths_with_emb_2_p, 'dd_paths_with_emb_2_n': dd_paths_with_emb_2_n,
                      'dd_paths_with_emb_3': dd_paths_with_emb_3, 'dd_paths_with_emb_5': dd_paths_with_emb_5}

        key = str(edge[0]) + '-' + str(edge[1])
        anchor_structures.update({key: structures})

    return anchor_structures


def anchor_structures_extract(graph, dd_path_mode, dd_path_threshold):
    # anchor_end_node = dfs_edges[0]
    # anchor_node = dfs_edges[1]
    # anchor_end_node = no_dfs_edges[0]
    # anchor_node = no_dfs_edges[1]
    dfs_edges = graph['dfs_edges']
    no_dfs_edges = graph['no_dfs_edges']
    dfs_anchor_structures = edge_as_extract(graph, dfs_edges, dd_path_mode, dd_path_threshold)
    no_dfs_anchor_structures = edge_as_extract(graph, no_dfs_edges, dd_path_mode, dd_path_threshold)
    anchor_structures = {**dfs_anchor_structures, **no_dfs_anchor_structures}
    graph.update({'anchor_structures': anchor_structures})
    # graph = {'dfs_edges': dfs_edges, 'no_dfs_edges': no_dfs_edges, 'anchor_structures': anchor_structures}
