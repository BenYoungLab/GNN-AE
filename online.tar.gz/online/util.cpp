#include "util.h"


void Util::print_format(unordered_map<string, double>& times, int cardinality, unordered_map<string, vector<int> >& dfs_ae_index_hits,
                        unordered_map<string, unordered_map<int, vector<int> > >& candidates, vector<string>& dfs_edge_strings,
                        vector<unordered_map<string, unordered_map<int, vector<int> > > >& match_candidates, string dense_index_type){
	double epsilon = 1e-9;
	double query_time = times["query_time"];
	int Proportion_sp = (times["sp_query_time"] / (query_time + epsilon))*100;
	int Proportion_sn = (times["sn_query_time"] / (query_time + epsilon))*100;
	int Proportion_union = (times["ae_union_time"] / (query_time + epsilon))*100;
	int Proportion_match = (times["match_time"] / (query_time + epsilon))*100;
	printf("SP Index Query Time: %.8f(ms) & Proportion %d\%\n", times["sp_query_time"], Proportion_sp);
	printf("SN Index Query Time: %.8f(ms) & Proportion %d\%\n", times["sn_query_time"], Proportion_sn);
	if (dense_index_type == "2"){
        int Proportion_dd_2 = (times["dd_2_query_time"] / (query_time + epsilon))*100;
        printf("DD-2 Index Query Time: %.8f(ms) & Proportion %d\%\n", times["dd_2_query_time"], Proportion_dd_2);
	}
	else if (dense_index_type == "3" || dense_index_type == "3-5"){
        int Proportion_dd_3 = (times["dd_3_query_time"] / (query_time + epsilon))*100;
        printf("DD-3 Index Query Time: %.8f(ms) & Proportion %d\%\n", times["dd_3_query_time"], Proportion_dd_3);
        if (dense_index_type == "3-5"){
            int Proportion_dd_5 = (times["dd_5_query_time"] / (query_time + epsilon))*100;
            printf("DD-5 Index Query Time: %.8f(ms) & Proportion %d\%\n", times["dd_5_query_time"], Proportion_dd_5);
	    }
	}
	printf("Candidate Anchors Union Time: %.8f(ms) & Proportion %d\%\n", times["ae_union_time"], Proportion_union);
	printf("Match Growth Time: %.8f(ms) & Proportion %d\%\n", times["match_time"], Proportion_match);
    printf("Total Query Time: %.8f(ms)\n", times["query_time"]);
    printf("# Matches: %d\n", cardinality);

    if (dense_index_type == "2"){
        int dfs_edge_num = dfs_ae_index_hits.size();
        int sp_hit = 0, sn_hit = 0, dd_2_hit = 0;
        for (const auto& pair : dfs_ae_index_hits){
            if (pair.second[0] != 0){
                sp_hit += 1;
            }
            if (pair.second[1] != 0){
                sn_hit += 1;
            }
            if (pair.second[2] != 0){
                dd_2_hit += 1;
            }
        }
        printf("Number of DFS Edges: %d\n", dfs_edge_num);
        printf("Index Hits: SP Index %d, SN Index %d, DD-2 Index %d\n", sp_hit, sn_hit, dd_2_hit);
    }
    else if (dense_index_type == "3"){
        int dfs_edge_num = dfs_ae_index_hits.size();
        int sp_hit = 0, sn_hit = 0, dd_3_hit = 0;
        for (const auto& pair : dfs_ae_index_hits){
            if (pair.second[0] != 0){
                sp_hit += 1;
            }
            if (pair.second[1] != 0){
                sn_hit += 1;
            }
            if (pair.second[2] != 0){
                dd_3_hit += 1;
            }
        }
        printf("Number of DFS Edges: %d\n", dfs_edge_num);
        printf("Index Hits: SP Index %d, SN Index %d, DD-3 Index %d\n", sp_hit, sn_hit, dd_3_hit);
    }
    else{
        int dfs_edge_num = dfs_ae_index_hits.size();
        int sp_hit = 0, sn_hit = 0, dd_3_hit = 0, dd_5_hit = 0;
        for (const auto& pair : dfs_ae_index_hits){
            if (pair.second[0] != 0){
                sp_hit += 1;
            }
            if (pair.second[1] != 0){
                sn_hit += 1;
            }
            if (pair.second[2] != 0){
                dd_3_hit += 1;
            }
            if (pair.second[3] != 0){
                dd_5_hit += 1;
            }
        }
        printf("Number of DFS Edges: %d\n", dfs_edge_num);
        printf("Index Hits: SP Index %d, SN Index %d, DD-3 Index %d, DD-5 Index %d\n", sp_hit, sn_hit, dd_3_hit, dd_5_hit);
    }
}


void Util::filtering_power(vector<vector<int> >& query_matches, unordered_map<string, unordered_map<int, vector<int> > >&
                           candidates, vector<int> dfs_nodes, vector<vector<int> >& dfs_edges, int graph_anchor_num){
    double sum_filtering_values = 0;
    for (int i = 0; i < dfs_edges.size(); i++){
        int anchor_end_node = dfs_edges[i][0];
        int anchor_node = dfs_edges[i][1];
        string anchor = to_string(anchor_end_node) + "-" + to_string(anchor_node);
        auto it_aen = find(dfs_nodes.begin(), dfs_nodes.end(), anchor_end_node);
        int index_aen = it_aen - dfs_nodes.begin();
        auto it_an = find(dfs_nodes.begin(), dfs_nodes.end(), anchor_node);
        int index_an = it_an - dfs_nodes.begin();
        set<string> ideal_match_anchors;
        for (int j = 0; j < query_matches.size(); j++){
            string match_anchor = to_string(query_matches[j][index_aen]) + "-" + to_string(query_matches[j][index_an]);
            ideal_match_anchors.insert(match_anchor);
        }

        int candidate_num = 0;
        for (const auto& pair : candidates[anchor]){
            candidate_num += pair.second.size();
        }
        double filtering_value = double(graph_anchor_num - candidate_num)/double(graph_anchor_num - ideal_match_anchors.size());
        sum_filtering_values += filtering_value;
    }

    double avg_filtering_value = double(sum_filtering_values)/double(dfs_edges.size());
    printf("Filtering power: %.8f\n", avg_filtering_value);
}


size_t Util::memory_cost_s_index(unordered_map<string, unordered_map<int, vector<int> > >& h_s_index){
    size_t memory_cost = 0;
    size_t per_int_size = sizeof(int);
    size_t per_string_size = sizeof(string);
    for (const auto& pair : h_s_index){
        memory_cost += per_string_size;
        for (const auto& pair : pair.second){
            memory_cost += per_int_size * (pair.second.size() + 1);
        }
    }

    return memory_cost;
}


size_t Util::memory_cost_dd_index(unordered_map<string, unordered_map<int, unordered_map<int, int> > >& h_dd_index){
    size_t memory_cost = 0;
    size_t per_int_size = sizeof(int);
    size_t per_string_size = sizeof(string);
    for (const auto& pair : h_dd_index){
        memory_cost += per_string_size;
        for (const auto& pair : pair.second){
            memory_cost += per_int_size * (2 * pair.second.size() + 1);
        }
    }

    return memory_cost;
}














