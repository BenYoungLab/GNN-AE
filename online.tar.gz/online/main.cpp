#include <iostream>
#include <fstream>
#include "read.h"
#include "hash.h"
#include "match.h"
#include "util.h"

#define BYTESTOMB(memory_cost) ((memory_cost)/(double)(1024 * 1024))

using namespace std;

ReadInput read_input;
HashData hash_data;
MatchData match_data;

// ./gnnae yeast
int main(int argc, char *argv[]){
    cerr << "Query Matching Program:" << endl;

    string data_graph_name = argv[1];
    double emb_precision = 100;
    // 10 is retained to 10 integer digits, and 0.1 is retained to 1 decimal place. You can select a 'emb_precision' value in {..., 100, 10, 1, 0.1, 0.01, ...}
    int parallel_threads = 8;
	int parallel_query_size = 6;
	string path_index_type = "3";  // "2", "3", "3-5"

    // Read the data graph
    string data_graph_path = "../data/" + data_graph_name + "/data_graph/" + data_graph_name + ".graph";
    ifstream data_graph_file(data_graph_path);
    read_input.read_graph(data_graph_file);
	cout << "Read data graph complete." << endl;

    // Read the query graph embeddings
    string query_dir = "../data/" + data_graph_name + "/query_graph_emb";
/* 	vector<string> query_type = {"dense", "sparse"};
	vector<int> query_size = {4, 8, 16, 24, 32};
	int num_query_size = 200;
	read_input.get_query_names_format2(query_type, query_size, num_query_size); */
	read_input.get_query_names_format1(query_dir);
	cout << "Read query names complete." << endl;

    // Read the sparse index and dense index
    string sparse_index_path = "../data/" + data_graph_name + "/sparse_index.out";
    ifstream sparse_index_file(sparse_index_path);
    if (path_index_type == "2"){
        string dense_index_2_path_p = "../data/" + data_graph_name + "/dense_index_2_p.out";
        ifstream dense_index_2_p_file(dense_index_2_path_p);
        string dense_index_2_path_n = "../data/" + data_graph_name + "/dense_index_2_n.out";
        ifstream dense_index_2_n_file(dense_index_2_path_n);
        read_input.read_index_format1(sparse_index_file, dense_index_2_p_file, dense_index_2_n_file, emb_precision);

    }
    else if (path_index_type == "3" || path_index_type == "3-5"){
        string dense_index_3_path = "../data/" + data_graph_name + "/dense_index_3.out";
        ifstream dense_index_3_file(dense_index_3_path);
        if (path_index_type == "3"){
            read_input.read_index_format2(sparse_index_file, dense_index_3_file, emb_precision);
        }
        else{
            string dense_index_5_path = "../data/" + data_graph_name + "/dense_index_5.out";
            ifstream dense_index_5_file(dense_index_5_path);
            read_input.read_index_format3(sparse_index_file, dense_index_3_file, dense_index_5_file, emb_precision);
        }
    }
    else{
        cout << "Error: there is no this mode." << endl;
    }
    cout << "Read all indexes complete." << endl;

    // Hash queries and 3 indexes
    if (path_index_type == "2"){
        hash_data.hash_index_format1(read_input.s_index, read_input.dd_2_p_index, read_input.dd_2_n_index, emb_precision);
    }
    else if (path_index_type == "3"){
        hash_data.hash_index_format2(read_input.s_index, read_input.dd_3_index, emb_precision);
    }
    else{
        hash_data.hash_index_format3(read_input.s_index, read_input.dd_3_index, read_input.dd_5_index, emb_precision);
    }
    cout << "Hash all indexes complete." << endl;

	// process a query
	cout << "***********************************************" << endl;
	double query_times = 0;
	for (int i = 0; i < read_input.query_names.size(); i++){
		QueryEmbPtr query_emb = new QueryEmb();
		read_input.read_query_emb(query_dir, read_input.query_names[i], emb_precision, query_emb);

	    HashQueryEmbPtr h_query_emb = new HashQueryEmb();
		hash_data.hash_query_emb(query_emb, emb_precision, h_query_emb);
		
		int data_graph_anchor_num = 2 * read_input.data_graph->num_e;

        // Match candidate and query result generation
        QueryResultPtr query_result = new QueryResult();
        if (path_index_type == "2"){
            match_data.query_process_format1(hash_data.h_s_index_p, hash_data.h_s_index_n, hash_data.h_dd_2_p_index,
                                             hash_data.h_dd_2_n_index, h_query_emb, read_input.query_names[i],
                                             read_input.data_graph->node_neighbors, query_result, parallel_threads,
                                             parallel_query_size, data_graph_anchor_num);

        }
        else if (path_index_type == "3"){
            match_data.query_process_format2(hash_data.h_s_index_p, hash_data.h_s_index_n, hash_data.h_dd_3_index,
                                             h_query_emb, read_input.query_names[i], read_input.data_graph->node_neighbors,
                                             query_result, parallel_threads, parallel_query_size, data_graph_anchor_num);
        }
        else{
            match_data.query_process_format3(hash_data.h_s_index_p, hash_data.h_s_index_n, hash_data.h_dd_3_index,
                                             hash_data.h_dd_5_index, h_query_emb, read_input.query_names[i],
                                             read_input.data_graph->node_neighbors, query_result, parallel_threads,
                                             parallel_query_size, data_graph_anchor_num);
        }

		query_times += query_result->query_time;

	    match_data.release_result_memory(query_result);
		delete query_emb, h_query_emb, query_result;
	}

    // Total Query time
    double avg_query_time = query_times / read_input.query_names.size();
    size_t index_size;
    if (path_index_type == "3-5"){
        index_size = Util::memory_cost_s_index(hash_data.h_s_index_p) + Util::memory_cost_s_index(hash_data.h_s_index_n)
                     + Util::memory_cost_dd_index(hash_data.h_dd_3_index) + Util::memory_cost_dd_index(hash_data.h_dd_5_index);
    }
    else if (path_index_type == "3"){
        index_size = Util::memory_cost_s_index(hash_data.h_s_index_p) + Util::memory_cost_s_index(hash_data.h_s_index_n)
                     + Util::memory_cost_dd_index(hash_data.h_dd_3_index);
    }
	else{
	    index_size = Util::memory_cost_s_index(hash_data.h_s_index_p) + Util::memory_cost_s_index(hash_data.h_s_index_n)
	                 + Util::memory_cost_dd_index(hash_data.h_dd_2_p_index) + Util::memory_cost_dd_index(hash_data.h_dd_2_n_index);
	}

    cout << "***********************************************" << endl;
    cout << "***********************************************" << endl;
    cout << "Query Number: " << read_input.query_names.size() << endl;
	cout << "Index Memory Cost (MB): " << BYTESTOMB(index_size) << endl;
    printf("Total Query Time for Query Set: %d(ms)\n", int(query_times));
    printf("Average Query Time for a Query: %.4f(ms)\n", avg_query_time);

    return 0;
}
