#ifndef HASH_H
#define HASH_H

#include "read.h"

using namespace std;

struct HashQueryEmb{
  vector<string> dfs_edge_strings;
  vector<vector<int> > dfs_edges;
  vector<int> dfs_nodes;
  unordered_map<int, int> query_node_map;
  unordered_map<string, string> dfs_edge_labels;
  unordered_map<int, vector<int> > no_dfs_position;
  unordered_map<string, string> p_ag_emb;
  unordered_map<string, string> n_ag_emb;
  unordered_map<string, vector<string> > dd_path_2_p;
  unordered_map<string, vector<string> > dd_path_2_n;
  unordered_map<string, vector<string> > dd_path_3;
  unordered_map<string, vector<string> > dd_path_5;
};
typedef HashQueryEmb *HashQueryEmbPtr;

class HashData{
  public:
    HashData(){}
    unordered_map<string, unordered_map<int, vector<int> > > h_s_index_p;
    unordered_map<string, unordered_map<int, vector<int> > > h_s_index_n;
    unordered_map<string, unordered_map<int, unordered_map<int, int> > > h_dd_2_p_index;
    unordered_map<string, unordered_map<int, unordered_map<int, int> > > h_dd_2_n_index;
	unordered_map<string, unordered_map<int, unordered_map<int, int> > > h_dd_3_index;
	unordered_map<string, unordered_map<int, unordered_map<int, int> > > h_dd_5_index;

    void hash_query_emb(QueryEmbPtr query_emb, int emb_precision, HashQueryEmbPtr h_query_emb);
    void hash_index_format1(vector<SIndexEntryPtr>& s_index, vector<DDIndexEntryPtr>& dd_2_p_index,
                            vector<DDIndexEntryPtr>& dd_2_n_index, int emb_precision);
    void hash_index_format2(vector<SIndexEntryPtr>& s_index, vector<DDIndexEntryPtr>& dd_3_index, int emb_precision);
    void hash_index_format3(vector<SIndexEntryPtr>& s_index, vector<DDIndexEntryPtr>& dd_3_index,
                            vector<DDIndexEntryPtr>& dd_5_index, int emb_precision);
  private:
    void hash_sparse_index(vector<SIndexEntryPtr>& s_index, int emb_precision);
    void hash_dense_index(vector<DDIndexEntryPtr>& dd_index, string path_mode);
};

extern HashData hash_data;

#endif
