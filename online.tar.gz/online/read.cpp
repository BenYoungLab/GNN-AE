#include "read.h"


vector<string> read_line(ifstream& input){
    string line;
    getline(input, line);
    vector<string> line_str;
    string str;
    istringstream devide(line);
    while(devide>>str){
        line_str.push_back(str);
    }

    return line_str;
}


void ReadInput::read_graph(ifstream& input){
    vector<string> line_str;
    while (!input.eof()){
        line_str = read_line(input);
//        for (int i = 0; i < line_str.size(); i++){
//            cout << line_str[i] << endl;
//        }
        while (line_str[0] == "t"){
            int num_v = atoi(line_str[1].c_str());
            int num_e = atoi(line_str[2].c_str());
            data_graph->num_v = num_v;
            data_graph->num_e = num_e;
            line_str = read_line(input);
        }
        while (line_str[0] == "v"){
            int node = atoi(line_str[1].c_str());
            int node_label = atoi(line_str[2].c_str());
            int degree = atoi(line_str[3].c_str());
            data_graph->nodes.push_back(node);
            data_graph->node_labels.push_back(node_label);
            data_graph->degrees.push_back(degree);
            line_str = read_line(input);
        }
        while (!input.eof() && line_str[0] == "e"){
            int from_node = atoi(line_str[1].c_str());
            int to_node = atoi(line_str[2].c_str());
            data_graph->from_nodes.push_back(from_node);
            data_graph->to_nodes.push_back(to_node);
			data_graph->node_neighbors[from_node][to_node] = 0;
			data_graph->node_neighbors[to_node][from_node] = 0;
            line_str = read_line(input);
        }
//        for (const auto &pair : data_graph->node_neighbors){
//            cout << "Key: " << pair.first << ", Value: ";
//            for (int value : pair.second){
//                std::cout << value << " ";
//            }
//            cout << std::endl;
//        }
    }
}


double roundoff(double value, int precision){
    double factor = pow(10.0, precision);    // default precision = 12
    double result = floor(value * factor) / factor;

    return result;
}


vector<string> get_files_linux(string path){
    DIR *dp;
    struct dirent *dirp;
    vector<string> file_names;
    if ((dp=opendir(path.c_str())) == NULL){
        perror("open dir error");
	}
    while ((dirp=readdir(dp)) != NULL){
		string name = string(dirp->d_name);
		if (name[0] == 'q'){
			file_names.push_back(name);
		}
	}

    closedir(dp);

    return file_names;
}


void ReadInput::get_query_names_format1(string query_dir){
	query_names = get_files_linux(query_dir);
}


void ReadInput::get_query_names_format2(vector<string>& query_type, vector<int>& query_size, int num_query_size){
	for (int i = 0; i < query_type.size(); i++){
		for (int j = 0; j < query_size.size(); j++){
			for (int k = 0; k < num_query_size; k++){
				string name = "query_" + query_type[i] + "_" + to_string(query_size[j]) + "_" + to_string(k) + ".graph";
				query_names.push_back(name);
			}
		}
	}
}


void ReadInput::read_query_emb(string query_dir, string query_name, int emb_precision, QueryEmbPtr query_emb){
    string query_path = query_dir + "/" + query_name;
    ifstream query_file(query_path);

    vector<string> line_str;
    while (!query_file.eof()){
        line_str = read_line(query_file);
        while (!query_file.eof() && line_str[0] == "dfs_edge"){
            string str;
            vector<int> dfs_edge;
            string dfs_edge_string = line_str[1];

            query_emb->dfs_edge_strings.push_back(dfs_edge_string);

            stringstream dfs_edge_stream(line_str[1]);
            while (getline(dfs_edge_stream, str, '-')){
                int node = atoi(str.c_str());
                dfs_edge.push_back(node);
            }
            query_emb->dfs_edges.push_back(dfs_edge);
            line_str = read_line(query_file);

            if (line_str[0] == "dfs_edge_labels"){
                int ag_end_node_label = atoi(line_str[1].c_str());
                int ag_node_label = atoi(line_str[2].c_str());
                vector<int> dfs_edge_labels = {ag_end_node_label, ag_node_label};
                query_emb->dfs_edge_labels.push_back(dfs_edge_labels);
                line_str = read_line(query_file);
            }
            if (line_str[0] == "p_ag_emb"){
                for (int j = 1; j < line_str.size(); j++){
                    double emb_j = roundoff(stod(line_str[j]), emb_precision);
                    query_emb->p_ag_emb[dfs_edge_string].push_back(emb_j);
                }
                line_str = read_line(query_file);
            }
            if (line_str[0] == "n_ag_emb"){
                for (int j = 1; j < line_str.size(); j++){
                    double emb_j = roundoff(stod(line_str[j]), emb_precision);
                    query_emb->n_ag_emb[dfs_edge_string].push_back(emb_j);
                }
                line_str = read_line(query_file);
            }

            while (!query_file.eof() && line_str[0] == "dd_path_2_p"){
				query_emb->dd_path_2_p[dfs_edge_string].push_back(line_str[1]);
                line_str = read_line(query_file);
            }

            while (!query_file.eof() && line_str[0] == "dd_path_2_n"){
				query_emb->dd_path_2_n[dfs_edge_string].push_back(line_str[1]);
                line_str = read_line(query_file);
            }

            while (!query_file.eof() && line_str[0] == "dd_path_3"){
				query_emb->dd_path_3[dfs_edge_string].push_back(line_str[1]);
                line_str = read_line(query_file);
            }

            while (!query_file.eof() && line_str[0] == "dd_path_5"){
				query_emb->dd_path_5[dfs_edge_string].push_back(line_str[1]);
                line_str = read_line(query_file);
            }
        }

        while (!query_file.eof() && line_str[0] == "no_dfs_edge"){
            if (line_str[0] == "no_dfs_edge"){
                line_str = read_line(query_file);
            }
            if (line_str[0] == "no_dfs_edge_labels"){
                line_str = read_line(query_file);
            }
            if (line_str[0] == "ss_emb"){
                line_str = read_line(query_file);
            }
            if (line_str[0] == "ss_ag_emb"){
                line_str = read_line(query_file);
            }
            if (line_str[0] == "ds_p_ag_emb"){
                line_str = read_line(query_file);
            }
            if (line_str[0] == "ds_n_ag_emb"){
                line_str = read_line(query_file);
            }
            while (!query_file.eof() && line_str[0] == "dd_path_emb"){
                line_str = read_line(query_file);
            }
        }

        while (!query_file.eof() && line_str[0] == "no_dfs_edge_dict"){
            int node_1_id = atoi(line_str[1].c_str());
			for (int i = 2; i < line_str.size(); i++){
                int node_i = atoi(line_str[i].c_str());
                query_emb->no_dfs_edge_dict[node_1_id].push_back(node_i);
            }
            line_str = read_line(query_file);
        }
    }
}


void ReadInput::read_index_format1(ifstream& sparse_input, ifstream& dense_2_p_input, ifstream& dense_2_n_input, int emb_precision){
    read_sparse_index(sparse_input, emb_precision);
    read_dense_index(dense_2_p_input, "2p");
    read_dense_index(dense_2_n_input, "2n");
}


void ReadInput::read_index_format2(ifstream& sparse_input, ifstream& dense_3_input, int emb_precision){
    read_sparse_index(sparse_input, emb_precision);
    read_dense_index(dense_3_input, "3");
}


void ReadInput::read_index_format3(ifstream& sparse_input, ifstream& dense_3_input, ifstream& dense_5_input, int emb_precision){
    read_sparse_index(sparse_input, emb_precision);
    read_dense_index(dense_3_input, "3");
    read_dense_index(dense_5_input, "5");
}


void ReadInput::read_sparse_index(ifstream& sparse_input, int emb_precision){
    vector<string> line_str;
    while (!sparse_input.eof()){
        line_str = read_line(sparse_input);
        while (!sparse_input.eof() && line_str[0] == "t"){
            SIndexEntryPtr s_index_entry = new SIndexEntry();
            s_index.push_back(s_index_entry);
            int entry_id = atoi(line_str[1].c_str());
            s_index_entry->t = entry_id;

            line_str = read_line(sparse_input);

            if (line_str[0] == "sparse_ag_emb"){
                for (int i = 1; i < line_str.size(); i++){
                    double emb_i = roundoff(stod(line_str[i]), emb_precision);
                    s_index_entry->sparse_ag_emb.push_back(emb_i);
                }
                line_str = read_line(sparse_input);
            }

            int ag_id = 0;
            while (!sparse_input.eof() && line_str[0] == "p_ae_labels"){
                int ag_end_node_label = atoi(line_str[1].c_str());
                int ag_node_label = atoi(line_str[2].c_str());
                s_index_entry->p_ae_labels[ag_id] = {ag_end_node_label, ag_node_label};
                line_str = read_line(sparse_input);

                unordered_map<int, vector<int> > matching;
                while (!sparse_input.eof() && line_str[0] == "p_m"){
                    int ag_end_node_id = atoi(line_str[1].c_str());
                    for (int i = 2; i < line_str.size(); i++){
                        int node_i = atoi(line_str[i].c_str());
                        matching[ag_end_node_id].push_back(node_i);
                    }
                    line_str = read_line(sparse_input);
                }
                s_index_entry->p_matchings[ag_id] = matching;

                ag_id++;
            }

            ag_id = 0;
            while (!sparse_input.eof() && line_str[0] == "n_ae_labels"){
                int ag_end_node_label = atoi(line_str[1].c_str());
                int ag_node_label = atoi(line_str[2].c_str());
                s_index_entry->n_ae_labels[ag_id] = {ag_end_node_label, ag_node_label};
                line_str = read_line(sparse_input);

                unordered_map<int, vector<int> > matching;
                while (!sparse_input.eof() && line_str[0] == "n_m"){
                    int ag_end_node_id = atoi(line_str[1].c_str());
                    for (int i = 2; i < line_str.size(); i++){
                        int node_i = atoi(line_str[i].c_str());
                        matching[ag_end_node_id].push_back(node_i);
                    }
                    line_str = read_line(sparse_input);
                }
                s_index_entry->n_matchings[ag_id] = matching;

                ag_id++;
            }
        }
    }
}


void ReadInput::read_dense_index(ifstream& dense_input, string path_mode){
    vector<string> line_str;
    while (!dense_input.eof()){
        line_str = read_line(dense_input);
        while (!dense_input.eof() && line_str[0] == "t"){
            DDIndexEntryPtr dd_index_entry = new DDIndexEntry();
            if (path_mode == "2p"){
                dd_2_p_index.push_back(dd_index_entry);
            }
            else if (path_mode == "2n"){
                dd_2_n_index.push_back(dd_index_entry);
            }
            else if (path_mode == "3"){
                dd_3_index.push_back(dd_index_entry);
            }
            else if (path_mode == "5"){
                dd_5_index.push_back(dd_index_entry);
            }
            else{
                printf("There no %s path mode.\n", path_mode);
            }

            int t = atoi(line_str[1].c_str());
            dd_index_entry->t = t;
            line_str = read_line(dense_input);

            while (!dense_input.eof() && line_str[0] == "path_emb"){
                dd_index_entry->path_emb = line_str[1];
                line_str = read_line(dense_input);
            }

            while (!dense_input.eof() && line_str[0] == "m"){
                int ag_end_node_id = atoi(line_str[1].c_str());
                for (int i = 2; i < line_str.size(); i++){
                    int node_i = atoi(line_str[i].c_str());
                    dd_index_entry->matchings[ag_end_node_id].push_back(node_i);
                }
                line_str = read_line(dense_input);
            }
        }
    }
}



