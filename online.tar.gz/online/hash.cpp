#include "hash.h"


string double_to_string(const double value, double precision) {
    string out_string;
    if (precision >= 1){
        int integer = value / precision;
        int out = integer * precision;
        out_string = to_string(out);
    }
    else{
        int multiplier = 1 / precision;
        int int_tmp = value * multiplier;
        int out_remainder = int_tmp % multiplier;
        int out_integer = value / 1;
        out_string = to_string(out_integer) + "." + to_string(out_remainder);
    }

    return out_string;
}


unordered_map<int, int> anchor_node_map(vector<vector<int> > dfs_edges){
    unordered_map<int, int> query_node_map;
    query_node_map[dfs_edges[0][0]] = 0;
    int map_value = 1;
    for (int i = 0; i < dfs_edges.size(); i++){
        query_node_map[dfs_edges[i][1]] = map_value;
        map_value++;
    }

    return query_node_map;
}


void HashData::hash_query_emb(QueryEmbPtr query_emb, int emb_precision, HashQueryEmbPtr h_query_emb){
    h_query_emb->dfs_edge_strings = query_emb->dfs_edge_strings;
    h_query_emb->dfs_edges = query_emb->dfs_edges;
    h_query_emb->dd_path_2_p = query_emb->dd_path_2_p;
    h_query_emb->dd_path_2_n = query_emb->dd_path_2_n;
    h_query_emb->dd_path_3 = query_emb->dd_path_3;
    h_query_emb->dd_path_5 = query_emb->dd_path_5;

	vector<vector<int> > dfs_edges = query_emb->dfs_edges;
	vector<int> dfs_nodes = {dfs_edges[0][0]};
	for (int i = 0; i < dfs_edges.size(); i++){
		dfs_nodes.push_back(dfs_edges[i][1]);
	}
	h_query_emb->dfs_nodes = dfs_nodes;

    unordered_map<int, vector<int> > no_dfs_position;
	unordered_map<int, vector<int> > no_dfs_edge_dict = query_emb->no_dfs_edge_dict;
	for (const auto& pair : no_dfs_edge_dict){
		auto it_first = find(dfs_nodes.begin(), dfs_nodes.end(), pair.first);
		int index_first = distance(dfs_nodes.begin(), it_first);
		vector<int> index_seconds;
		for (int i = 0; i < pair.second.size(); i++){
			auto it = find(dfs_nodes.begin(), dfs_nodes.end(), pair.second[i]);
		    int index = distance(dfs_nodes.begin(), it);
			index_seconds.push_back(index);
		}
		no_dfs_position[index_first] = index_seconds;
	}
	h_query_emb->no_dfs_position = no_dfs_position;

    h_query_emb->query_node_map = anchor_node_map(query_emb->dfs_edges);

    for (int i = 0; i < query_emb->dfs_edge_labels.size(); i++){
        vector<int> dfs_edge_labels = query_emb->dfs_edge_labels[i];
        string dfs_edge_labels_string = to_string(dfs_edge_labels[0]) + "-" + to_string(dfs_edge_labels[1]);
        h_query_emb->dfs_edge_labels[query_emb->dfs_edge_strings[i]] = dfs_edge_labels_string;
    }

    unordered_map<string, vector<double> > p_ag_emb = query_emb->p_ag_emb;
    for (const auto& pair : p_ag_emb){
        string p_ag_emb_values = double_to_string(pair.second[0], emb_precision);
        for (int i = 1; i < pair.second.size(); i++){
            p_ag_emb_values = p_ag_emb_values + "-" + double_to_string(pair.second[i], emb_precision);
        }
        h_query_emb->p_ag_emb[pair.first] = p_ag_emb_values;
    }

    unordered_map<string, vector<double> > n_ag_emb = query_emb->n_ag_emb;
    for (const auto& pair : n_ag_emb){
        string n_ag_emb_values = double_to_string(pair.second[0], emb_precision);
        for (int i = 1; i < pair.second.size(); i++){
            n_ag_emb_values = n_ag_emb_values + "-" + double_to_string(pair.second[i], emb_precision);
        }
        h_query_emb->n_ag_emb[pair.first] = n_ag_emb_values;
    }
}


void HashData::hash_index_format1(vector<SIndexEntryPtr>& s_index, vector<DDIndexEntryPtr>& dd_2_p_index,
                                  vector<DDIndexEntryPtr>& dd_2_n_index, int emb_precision){
    hash_sparse_index(s_index, emb_precision);
    hash_dense_index(dd_2_p_index, "2p");
    hash_dense_index(dd_2_n_index, "2n");
}


void HashData::hash_index_format2(vector<SIndexEntryPtr>& s_index, vector<DDIndexEntryPtr>& dd_3_index, int emb_precision){
    hash_sparse_index(s_index, emb_precision);
    hash_dense_index(dd_3_index, "3");
}


void HashData::hash_index_format3(vector<SIndexEntryPtr>& s_index, vector<DDIndexEntryPtr>& dd_3_index,
                                  vector<DDIndexEntryPtr>& dd_5_index, int emb_precision){
    hash_sparse_index(s_index, emb_precision);
    hash_dense_index(dd_3_index, "3");
    hash_dense_index(dd_5_index, "5");
}


void HashData::hash_sparse_index(vector<SIndexEntryPtr>& s_index, int emb_precision){
    for (int i = 0; i < s_index.size(); i++){
        vector<double> sparse_ag_emb = s_index[i]->sparse_ag_emb;
        string sparse_ag_emb_values = double_to_string(sparse_ag_emb[0], emb_precision);
        for (int j = 1; j < sparse_ag_emb.size(); j++){
            sparse_ag_emb_values = sparse_ag_emb_values + "-" + double_to_string(sparse_ag_emb[j], emb_precision);
        }

        unordered_map<int, vector<int> > p_ae_labels = s_index[i]->p_ae_labels;
        for (const auto& pair : p_ae_labels){
            vector<int> p_ae_labels = s_index[i]->p_ae_labels[pair.first];
            string p_ae_labels_string = to_string(p_ae_labels[0]) + "-" + to_string(p_ae_labels[1]);

            string unique_emb = sparse_ag_emb_values + "+" + p_ae_labels_string;

            h_s_index_p[unique_emb] = s_index[i]->p_matchings[pair.first];
        }

        if (s_index[i]->n_ae_labels.size() != 0){
            unordered_map<int, vector<int> > n_ae_labels = s_index[i]->n_ae_labels;
            for (const auto& pair : n_ae_labels){
                vector<int> n_ae_labels = s_index[i]->n_ae_labels[pair.first];
                string n_ae_labels_string = to_string(n_ae_labels[0]) + "-" + to_string(n_ae_labels[1]);

                string unique_emb = sparse_ag_emb_values + "+" + n_ae_labels_string;

                h_s_index_n[unique_emb] = s_index[i]->n_matchings[pair.first];
            }
        }
    }
}


void HashData::hash_dense_index(vector<DDIndexEntryPtr>& dd_index, string path_mode){
    for (int i = 0; i < dd_index.size(); i++){
        string path_emb = dd_index[i]->path_emb;

        unordered_map<int, unordered_map<int, int> > h_matchings;
        unordered_map<int, vector<int> > matchings = dd_index[i]->matchings;
        for (const auto& pair : matchings){
            unordered_map<int, int> h_anchor_node_match;
            int position = 0;
            vector<int> anchor_node_match = pair.second;
            for (int j = 0; j < anchor_node_match.size(); j++){
                h_anchor_node_match[anchor_node_match[j]] = position;
                position++;
            }
            h_matchings[pair.first] = h_anchor_node_match;
        }

        if (path_mode == "2p"){
            h_dd_2_p_index[path_emb] = h_matchings;
        }
        else if (path_mode == "2n"){
            h_dd_2_n_index[path_emb] = h_matchings;
        }
        else if (path_mode == "3"){
            h_dd_3_index[path_emb] = h_matchings;
        }
        else if (path_mode == "5"){
            h_dd_5_index[path_emb] = h_matchings;
        }
        else{
            printf("There no %s path mode.\n", path_mode);
        }
    }
}



