#ifndef READ_H
#define READ_H
#include <fstream>
#include <string>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <vector>
#include <cmath>
#include <dirent.h>
#include <algorithm>
#include <unordered_map>

using namespace std;

struct DataGraph{
  int num_v;
  int num_e;
  vector<int> nodes;
  vector<int> node_labels;
  vector<int> degrees;
  vector<int> from_nodes;
  vector<int> to_nodes;
  unordered_map<int, unordered_map<int, int> > node_neighbors;
};
typedef DataGraph *DataGraphPtr;

struct QueryEmb{
  vector<string> dfs_edge_strings;
  vector<vector<int> > dfs_edges;
  vector<vector<int> > dfs_edge_labels;
  unordered_map<int, vector<int> > no_dfs_edge_dict;
  unordered_map<string, vector<double> > p_ag_emb;
  unordered_map<string, vector<double> > n_ag_emb;
  unordered_map<string, vector<string> > dd_path_2_p;
  unordered_map<string, vector<string> > dd_path_2_n;
  unordered_map<string, vector<string> > dd_path_3;
  unordered_map<string, vector<string> > dd_path_5;
};
typedef QueryEmb *QueryEmbPtr;

struct SIndexEntry{
  int t;
  vector<double> sparse_ag_emb;
  unordered_map<int, vector<int> > p_ae_labels;
  unordered_map<int, unordered_map<int, vector<int> > > p_matchings;
  unordered_map<int, vector<int> > n_ae_labels;
  unordered_map<int, unordered_map<int, vector<int> > > n_matchings;
};
typedef SIndexEntry *SIndexEntryPtr;

struct DDIndexEntry{
  int t;
  string path_emb;
  unordered_map<int, vector<int> >  matchings;
};
typedef DDIndexEntry *DDIndexEntryPtr;

class ReadInput{
  public:
    ReadInput(){}
	DataGraphPtr data_graph = new DataGraph();
	vector<string> query_names;
	vector<SIndexEntryPtr> s_index;
	vector<DDIndexEntryPtr> dd_2_p_index;
	vector<DDIndexEntryPtr> dd_2_n_index;
	vector<DDIndexEntryPtr> dd_3_index;
	vector<DDIndexEntryPtr> dd_5_index;

    void read_graph(ifstream& input);
	void get_query_names_format1(string query_dir);
	void get_query_names_format2(vector<string>& query_type, vector<int>& query_size, int num_query_size);
    void read_query_emb(string query_dir, string query_name, int emb_precision, QueryEmbPtr query_emb);
    void read_index_format1(ifstream& sparse_input, ifstream& dense_2_p_input, ifstream& dense_2_n_input, int emb_precision);
    void read_index_format2(ifstream& sparse_input, ifstream& dense_3_input, int emb_precision);
    void read_index_format3(ifstream& sparse_input, ifstream& dense_3_input, ifstream& dense_5_input, int emb_precision);
  private:
    void read_sparse_index(ifstream& sparse_input, int emb_precision);
    void read_dense_index(ifstream& dense_input, string path_mode);
};

extern ReadInput read_input;

#endif
