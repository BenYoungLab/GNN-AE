#ifndef MATCH_H
#define MATCH_H

#include <chrono>
#include <future>
#include <omp.h>
#include "hash.h"
#include "util.h"

using namespace std;

struct QueryResult{
    int cardinality;
    double query_time;
	double sp_query_time;
	double sn_query_time;
	double dd_2_query_time;
	double dd_3_query_time;
	double dd_5_query_time;
	double ae_union_time;
	double match_time;
    unordered_map<int, int> query_node_map;
    vector<vector<int> > query_matches;
    unordered_map<string, unordered_map<int, vector<int> > > ae_match_candidates;
};
typedef QueryResult *QueryResultPtr;

struct MatchResult{
    vector<vector<int> > query_matches;
    vector<unordered_map<int, int> > query_matches_dict;
};
typedef MatchResult *MatchResultPtr;

class MatchData{
  public:
    MatchData(){}

    void query_process_format1(unordered_map<string, unordered_map<int, vector<int> > >& h_s_index_p,
                               unordered_map<string, unordered_map<int, vector<int> > >& h_s_index_n,
                               unordered_map<string, unordered_map<int, unordered_map<int, int> > >& h_dd_2_p_index,
                               unordered_map<string, unordered_map<int, unordered_map<int, int> > >& h_dd_2_n_index,
                               HashQueryEmbPtr h_query_emb, string query_name, unordered_map<int, unordered_map<int,
                               int> >& node_neighbors, QueryResultPtr query_result, int parallel_threads, int parallel_query_size, int graph_anchor_num);
    void query_process_format2(unordered_map<string, unordered_map<int, vector<int> > >& h_s_index_p,
                               unordered_map<string, unordered_map<int, vector<int> > >& h_s_index_n,
                               unordered_map<string, unordered_map<int, unordered_map<int, int> > >& h_dd_3_index,
                               HashQueryEmbPtr h_query_emb, string query_name, unordered_map<int, unordered_map<int,
                               int> >& node_neighbors, QueryResultPtr query_result, int parallel_threads, int parallel_query_size, int graph_anchor_num);
    void query_process_format3(unordered_map<string, unordered_map<int, vector<int> > >& h_s_index_p,
                               unordered_map<string, unordered_map<int, vector<int> > >& h_s_index_n,
                               unordered_map<string, unordered_map<int, unordered_map<int, int> > >& h_dd_3_index,
                               unordered_map<string, unordered_map<int, unordered_map<int, int> > >& h_dd_5_index,
                               HashQueryEmbPtr h_query_emb, string query_name, unordered_map<int, unordered_map<int,
                               int> >& node_neighbors, QueryResultPtr query_result, int parallel_threads, int parallel_query_size, int graph_anchor_num);
    void release_result_memory(QueryResultPtr query_result);
  private:
    void match_s_index_p(unordered_map<string, unordered_map<int, vector<int> > >& h_s_index_p, HashQueryEmbPtr h_query_emb,
                         unordered_map<string, unordered_map<int, vector<int> > >& ae_sp_match_candidates);
    void match_s_index_n(unordered_map<string, unordered_map<int, vector<int> > >& h_s_index_n, HashQueryEmbPtr h_query_emb,
                         unordered_map<string, unordered_map<int, vector<int> > >& ae_sn_match_candidates);
    void match_dd_2_index(unordered_map<string, unordered_map<int, unordered_map<int, int> > >& h_dd_p_index, unordered_map<string,
                          unordered_map<int, unordered_map<int, int> > >& h_dd_n_index, vector<string>& dfs_edge_strings,
                          unordered_map<string, vector<string> >& dd_path_p_emb, unordered_map<string, vector<string> >& dd_path_n_emb,
                          unordered_map<string, unordered_map<int, vector<int> > >& ae_dd_match_candidates);
    void match_dd_index(unordered_map<string, unordered_map<int, unordered_map<int, int> > >& h_dd_index, vector<string>&
                        dfs_edge_strings, unordered_map<string, vector<string> >& dd_path_emb, unordered_map<string,
                        unordered_map<int, vector<int> > >& ae_dd_match_candidates);
    void candidate_ae_union(vector<unordered_map<string, unordered_map<int, vector<int> > > >& match_candidates,
                            unordered_map<string, unordered_map<int, vector<int> > >& candidates);
    void index_hit(vector<unordered_map<string, unordered_map<int, vector<int> > > >& match_candidates,
                   unordered_map<string, vector<int> >& dfs_ae_index_hits, string dense_index_type);
	void query_match(HashQueryEmbPtr h_query_emb, unordered_map<string, unordered_map<int, vector<int> > >& candidates,
                     unordered_map<int, unordered_map<int, int> >& node_neighbors, QueryResultPtr query_result, int parallel_threads,
                     MatchResultPtr initial_query_result, unordered_map<int, MatchResultPtr> parallel_query_result, int parallel_query_size);
};

extern MatchData match_data;

#endif
