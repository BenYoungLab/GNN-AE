#include "match.h"


void MatchData::candidate_ae_union(vector<unordered_map<string, unordered_map<int, vector<int> > > >& match_candidates,
                                   unordered_map<string, unordered_map<int, vector<int> > >& candidates){
    candidates = match_candidates[0];
    for (int i = 1; i < match_candidates.size(); i++){
        for (const auto& pair : candidates){
            unordered_map<int, vector<int> > result_value = pair.second;
            unordered_map<int, vector<int> > candidate_i_value = match_candidates[i][pair.first];
            for (const auto& pair : candidate_i_value){
                if (result_value.count(pair.first) != 0){
                    for (int j = 0; j < pair.second.size(); j++){
                        result_value[pair.first].push_back(pair.second[j]);
                    }
                }
                else{
                    result_value[pair.first] = pair.second;
                }
            }
            candidates[pair.first] = result_value;
        }
    }
}


void MatchData::index_hit(vector<unordered_map<string, unordered_map<int, vector<int> > > >& match_candidates,
                          unordered_map<string, vector<int> >& dfs_ae_index_hits, string dense_index_type){
	if (dense_index_type == "2"){
        for (const auto& pair : match_candidates[1]){
            vector<int> dfs_ae_hit;
            dfs_ae_hit.push_back(pair.second.size());
            dfs_ae_hit.push_back(match_candidates[2][pair.first].size());
            dfs_ae_hit.push_back(match_candidates[0][pair.first].size());

            dfs_ae_index_hits[pair.first] = dfs_ae_hit;
        }
	}
	else if (dense_index_type == "3"){
        for (const auto& pair : match_candidates[1]){
            vector<int> dfs_ae_hit;
            dfs_ae_hit.push_back(pair.second.size());
            dfs_ae_hit.push_back(match_candidates[2][pair.first].size());
            dfs_ae_hit.push_back(match_candidates[0][pair.first].size());

            dfs_ae_index_hits[pair.first] = dfs_ae_hit;
        }
	}
	else{
        for (const auto& pair : match_candidates[2]){
            vector<int> dfs_ae_hit;
            dfs_ae_hit.push_back(pair.second.size());
            dfs_ae_hit.push_back(match_candidates[3][pair.first].size());
            dfs_ae_hit.push_back(match_candidates[0][pair.first].size());
            dfs_ae_hit.push_back(match_candidates[1][pair.first].size());

            dfs_ae_index_hits[pair.first] = dfs_ae_hit;
        }
	}
}


void MatchData::query_process_format1(unordered_map<string, unordered_map<int, vector<int> > >& h_s_index_p,
                                      unordered_map<string, unordered_map<int, vector<int> > >& h_s_index_n,
                                      unordered_map<string, unordered_map<int, unordered_map<int, int> > >& h_dd_2_p_index,
                                      unordered_map<string, unordered_map<int, unordered_map<int, int> > >& h_dd_2_n_index,
                                      HashQueryEmbPtr h_query_emb, string query_name, unordered_map<int, unordered_map<int,
                                      int> >& node_neighbors, QueryResultPtr query_result, int parallel_threads,
                                      int parallel_query_size, int graph_anchor_num){
    cout << "-----------------------------------------------" << endl;
    cout << query_name << ":" << endl;
	query_result->query_node_map = h_query_emb->query_node_map;

    unordered_map<string, unordered_map<int, vector<int> > > ae_sp_match_candidates;
    unordered_map<string, unordered_map<int, vector<int> > > ae_sn_match_candidates;
    unordered_map<string, unordered_map<int, vector<int> > > ae_dd_2_match_candidates;
    unordered_map<string, unordered_map<int, vector<int> > > candidates;
    unordered_map<string, vector<int> > dfs_ae_index_hits;
    MatchResultPtr initial_query_result = new MatchResult();
    unordered_map<int, MatchResultPtr> parallel_query_result;
	for (int i = 0; i < parallel_threads; i++){
        MatchResultPtr query_result_tmp = new MatchResult();
        parallel_query_result[i] = query_result_tmp;
	}

    typedef chrono::high_resolution_clock Clock;
    auto start_time = Clock::now();

    match_s_index_p(h_s_index_p, h_query_emb, ae_sp_match_candidates);
    auto sp_end_time = Clock::now();

    match_s_index_n(h_s_index_n, h_query_emb, ae_sn_match_candidates);
	auto sn_end_time = Clock::now();

    match_dd_2_index(h_dd_2_p_index, h_dd_2_n_index, h_query_emb->dfs_edge_strings, h_query_emb->dd_path_2_p, h_query_emb->dd_path_2_n, ae_dd_2_match_candidates);
	auto dd_2_end_time = Clock::now();

    vector<unordered_map<string, unordered_map<int, vector<int> > > > match_candidates;
    match_candidates = {ae_dd_2_match_candidates, ae_sp_match_candidates, ae_sn_match_candidates};
    candidate_ae_union(match_candidates, candidates);
	auto ae_union_end_time = Clock::now();

	query_match(h_query_emb, candidates, node_neighbors, query_result, parallel_threads, initial_query_result, parallel_query_result, parallel_query_size);
	auto end_time = Clock::now();

	index_hit(match_candidates, dfs_ae_index_hits, "2");

    unordered_map<string, double> times;
	double sp_query_time = chrono::duration_cast<chrono::nanoseconds>(sp_end_time - start_time).count() / 1e+6;
    query_result->sp_query_time = sp_query_time;
	times["sp_query_time"] = sp_query_time;
	double sn_query_time = chrono::duration_cast<chrono::nanoseconds>(sn_end_time - sp_end_time).count() / 1e+6;
    query_result->sn_query_time = sn_query_time;
	times["sn_query_time"] = sn_query_time;
	double dd_2_query_time = chrono::duration_cast<chrono::nanoseconds>(dd_2_end_time - sn_end_time).count() / 1e+6;
    query_result->dd_2_query_time = dd_2_query_time;
	times["dd_2_query_time"] = dd_2_query_time;
	double ae_union_time = chrono::duration_cast<chrono::nanoseconds>(ae_union_end_time - dd_2_end_time).count() / 1e+6;
    query_result->ae_union_time = ae_union_time;
	times["ae_union_time"] = ae_union_time;
	double match_time = chrono::duration_cast<chrono::nanoseconds>(end_time - ae_union_end_time).count() / 1e+6;
    query_result->match_time = match_time;
	times["match_time"] = match_time;
    double query_time = chrono::duration_cast<chrono::nanoseconds>(end_time - start_time).count() / 1e+6;
    query_result->query_time = query_time;
	times["query_time"] = query_time;

    query_result->ae_match_candidates = candidates;

    Util::filtering_power(query_result->query_matches, candidates, h_query_emb->dfs_nodes, h_query_emb->dfs_edges, graph_anchor_num);

    Util::print_format(times, query_result->cardinality, dfs_ae_index_hits, candidates, h_query_emb->dfs_edge_strings, match_candidates, "2");
}


void MatchData::query_process_format2(unordered_map<string, unordered_map<int, vector<int> > >& h_s_index_p,
                                      unordered_map<string, unordered_map<int, vector<int> > >& h_s_index_n,
                                      unordered_map<string, unordered_map<int, unordered_map<int, int> > >& h_dd_3_index,
                                      HashQueryEmbPtr h_query_emb, string query_name, unordered_map<int, unordered_map<int,
                                      int> >& node_neighbors, QueryResultPtr query_result, int parallel_threads,
                                      int parallel_query_size, int graph_anchor_num){
    cout << "-----------------------------------------------" << endl;
    cout << query_name << ":" << endl;
	query_result->query_node_map = h_query_emb->query_node_map;

    unordered_map<string, unordered_map<int, vector<int> > > ae_sp_match_candidates;
    unordered_map<string, unordered_map<int, vector<int> > > ae_sn_match_candidates;
    unordered_map<string, unordered_map<int, vector<int> > > ae_dd_3_match_candidates;
    unordered_map<string, unordered_map<int, vector<int> > > candidates;
    unordered_map<string, vector<int> > dfs_ae_index_hits;
    MatchResultPtr initial_query_result = new MatchResult();
    unordered_map<int, MatchResultPtr> parallel_query_result;
	for (int i = 0; i < parallel_threads; i++){
        MatchResultPtr query_result_tmp = new MatchResult();
        parallel_query_result[i] = query_result_tmp;
	}

    typedef chrono::high_resolution_clock Clock;
    auto start_time = Clock::now();

    match_s_index_p(h_s_index_p, h_query_emb, ae_sp_match_candidates);
    auto sp_end_time = Clock::now();

    match_s_index_n(h_s_index_n, h_query_emb, ae_sn_match_candidates);
	auto sn_end_time = Clock::now();

    match_dd_index(h_dd_3_index, h_query_emb->dfs_edge_strings, h_query_emb->dd_path_3, ae_dd_3_match_candidates);
	auto dd_3_end_time = Clock::now();

    vector<unordered_map<string, unordered_map<int, vector<int> > > > match_candidates;
    match_candidates = {ae_dd_3_match_candidates, ae_sp_match_candidates, ae_sn_match_candidates};
    candidate_ae_union(match_candidates, candidates);
	auto ae_union_end_time = Clock::now();

	query_match(h_query_emb, candidates, node_neighbors, query_result, parallel_threads, initial_query_result, parallel_query_result, parallel_query_size);
	auto end_time = Clock::now();

	index_hit(match_candidates, dfs_ae_index_hits, "3");

    unordered_map<string, double> times;
	double sp_query_time = chrono::duration_cast<chrono::nanoseconds>(sp_end_time - start_time).count() / 1e+6;
    query_result->sp_query_time = sp_query_time;
	times["sp_query_time"] = sp_query_time;
	double sn_query_time = chrono::duration_cast<chrono::nanoseconds>(sn_end_time - sp_end_time).count() / 1e+6;
    query_result->sn_query_time = sn_query_time;
	times["sn_query_time"] = sn_query_time;
	double dd_3_query_time = chrono::duration_cast<chrono::nanoseconds>(dd_3_end_time - sn_end_time).count() / 1e+6;
    query_result->dd_3_query_time = dd_3_query_time;
	times["dd_3_query_time"] = dd_3_query_time;
	double ae_union_time = chrono::duration_cast<chrono::nanoseconds>(ae_union_end_time - dd_3_end_time).count() / 1e+6;
    query_result->ae_union_time = ae_union_time;
	times["ae_union_time"] = ae_union_time;
	double match_time = chrono::duration_cast<chrono::nanoseconds>(end_time - ae_union_end_time).count() / 1e+6;
    query_result->match_time = match_time;
	times["match_time"] = match_time;
    double query_time = chrono::duration_cast<chrono::nanoseconds>(end_time - start_time).count() / 1e+6;
    query_result->query_time = query_time;
	times["query_time"] = query_time;

    query_result->ae_match_candidates = candidates;

    Util::filtering_power(query_result->query_matches, candidates, h_query_emb->dfs_nodes, h_query_emb->dfs_edges, graph_anchor_num);

    Util::print_format(times, query_result->cardinality, dfs_ae_index_hits, candidates, h_query_emb->dfs_edge_strings, match_candidates, "3");
}


void MatchData::query_process_format3(unordered_map<string, unordered_map<int, vector<int> > >& h_s_index_p,
                                      unordered_map<string, unordered_map<int, vector<int> > >& h_s_index_n,
                                      unordered_map<string, unordered_map<int, unordered_map<int, int> > >& h_dd_3_index,
                                      unordered_map<string, unordered_map<int, unordered_map<int, int> > >& h_dd_5_index,
                                      HashQueryEmbPtr h_query_emb, string query_name, unordered_map<int, unordered_map<int,
                                      int> >& node_neighbors, QueryResultPtr query_result, int parallel_threads,
                                      int parallel_query_size, int graph_anchor_num){
    cout << "-----------------------------------------------" << endl;
    cout << query_name << ":" << endl;
	query_result->query_node_map = h_query_emb->query_node_map;

    unordered_map<string, unordered_map<int, vector<int> > > ae_sp_match_candidates;
    unordered_map<string, unordered_map<int, vector<int> > > ae_sn_match_candidates;
    unordered_map<string, unordered_map<int, vector<int> > > ae_dd_3_match_candidates;
    unordered_map<string, unordered_map<int, vector<int> > > ae_dd_5_match_candidates;
    unordered_map<string, unordered_map<int, vector<int> > > candidates;
    unordered_map<string, vector<int> > dfs_ae_index_hits;
    MatchResultPtr initial_query_result = new MatchResult();
    unordered_map<int, MatchResultPtr> parallel_query_result;
	for (int i = 0; i < parallel_threads; i++){
        MatchResultPtr query_result_tmp = new MatchResult();
        parallel_query_result[i] = query_result_tmp;
	}

    typedef chrono::high_resolution_clock Clock;
    auto start_time = Clock::now();

    match_s_index_p(h_s_index_p, h_query_emb, ae_sp_match_candidates);
    auto sp_end_time = Clock::now();

    match_s_index_n(h_s_index_n, h_query_emb, ae_sn_match_candidates);
	auto sn_end_time = Clock::now();

    match_dd_index(h_dd_3_index, h_query_emb->dfs_edge_strings, h_query_emb->dd_path_3, ae_dd_3_match_candidates);
	auto dd_3_end_time = Clock::now();

	match_dd_index(h_dd_5_index, h_query_emb->dfs_edge_strings, h_query_emb->dd_path_5, ae_dd_5_match_candidates);
	auto dd_5_end_time = Clock::now();

    vector<unordered_map<string, unordered_map<int, vector<int> > > > match_candidates;
    match_candidates = {ae_dd_3_match_candidates, ae_dd_5_match_candidates, ae_sp_match_candidates, ae_sn_match_candidates};
    candidate_ae_union(match_candidates, candidates);
	auto ae_union_end_time = Clock::now();

	query_match(h_query_emb, candidates, node_neighbors, query_result, parallel_threads, initial_query_result, parallel_query_result, parallel_query_size);
	auto end_time = Clock::now();

	index_hit(match_candidates, dfs_ae_index_hits, "3-5");

    unordered_map<string, double> times;
	double sp_query_time = chrono::duration_cast<chrono::nanoseconds>(sp_end_time - start_time).count() / 1e+6;
    query_result->sp_query_time = sp_query_time;
	times["sp_query_time"] = sp_query_time;
	double sn_query_time = chrono::duration_cast<chrono::nanoseconds>(sn_end_time - sp_end_time).count() / 1e+6;
    query_result->sn_query_time = sn_query_time;
	times["sn_query_time"] = sn_query_time;
	double dd_3_query_time = chrono::duration_cast<chrono::nanoseconds>(dd_3_end_time - sn_end_time).count() / 1e+6;
    query_result->dd_3_query_time = dd_3_query_time;
	times["dd_3_query_time"] = dd_3_query_time;
	double dd_5_query_time = chrono::duration_cast<chrono::nanoseconds>(dd_5_end_time - dd_3_end_time).count() / 1e+6;
    query_result->dd_5_query_time = dd_5_query_time;
	times["dd_5_query_time"] = dd_5_query_time;
	double ae_union_time = chrono::duration_cast<chrono::nanoseconds>(ae_union_end_time - dd_5_end_time).count() / 1e+6;
    query_result->ae_union_time = ae_union_time;
	times["ae_union_time"] = ae_union_time;
	double match_time = chrono::duration_cast<chrono::nanoseconds>(end_time - ae_union_end_time).count() / 1e+6;
    query_result->match_time = match_time;
	times["match_time"] = match_time;
    double query_time = chrono::duration_cast<chrono::nanoseconds>(end_time - start_time).count() / 1e+6;
    query_result->query_time = query_time;
	times["query_time"] = query_time;

    query_result->ae_match_candidates = candidates;

    Util::filtering_power(query_result->query_matches, candidates, h_query_emb->dfs_nodes, h_query_emb->dfs_edges, graph_anchor_num);

    Util::print_format(times, query_result->cardinality, dfs_ae_index_hits, candidates, h_query_emb->dfs_edge_strings, match_candidates, "3-5");
}


void MatchData::match_s_index_p(unordered_map<string, unordered_map<int, vector<int> > >& h_s_index_p, HashQueryEmbPtr h_query_emb,
                                unordered_map<string, unordered_map<int, vector<int> > >& ae_sp_match_candidates){
    for (int i = 0; i < h_query_emb->dfs_edge_strings.size(); i++){
        string dfs_edge_string = h_query_emb->dfs_edge_strings[i];
        string p_ag_emb_string = h_query_emb->p_ag_emb[dfs_edge_string];
        string dfs_edge_labels_string = h_query_emb->dfs_edge_labels[dfs_edge_string];
        string unique_emb = p_ag_emb_string + "+" + dfs_edge_labels_string;

        if (h_s_index_p.count(unique_emb) == 0){
            ae_sp_match_candidates[dfs_edge_string] = {};
        }
        else{
            ae_sp_match_candidates[dfs_edge_string] = h_s_index_p[unique_emb];
        }
    }
}


void MatchData::match_s_index_n(unordered_map<string, unordered_map<int, vector<int> > >& h_s_index_n, HashQueryEmbPtr h_query_emb,
                                unordered_map<string, unordered_map<int, vector<int> > >& ae_sn_match_candidates){
    for (int i = 0; i < h_query_emb->dfs_edge_strings.size(); i++){
        string dfs_edge_string = h_query_emb->dfs_edge_strings[i];
        string n_ag_emb_string = h_query_emb->n_ag_emb[dfs_edge_string];
        string dfs_edge_labels_string = h_query_emb->dfs_edge_labels[dfs_edge_string];
        string unique_emb = n_ag_emb_string + "+" + dfs_edge_labels_string;

        if (h_s_index_n.count(unique_emb) == 0){
            ae_sn_match_candidates[dfs_edge_string] = {};
        }
        else{
            ae_sn_match_candidates[dfs_edge_string] = h_s_index_n[unique_emb];
        }
    }
}


void path_candidate_intersect(unordered_map<int, unordered_map<int, int> >& tmp, unordered_map<int, unordered_map<int, int> >& map_b){
    unordered_map<int, unordered_map<int, int> > result;
    for (const auto& pair : tmp){
        int map_a_key = pair.first;
        if (map_b.count(map_a_key) != 0){
            unordered_map<int, int> intersection;
            unordered_map<int, int> map_a_value = pair.second;
            unordered_map<int, int> map_b_value = map_b[map_a_key];
            for (const auto& pair : map_a_value){
                if (map_b_value.count(pair.first) != 0){
                    intersection[pair.first] = pair.second;
                }
            }
            if (!intersection.empty()){
                result[map_a_key] = intersection;
            }
        }
    }

    tmp.swap(result);
}


void MatchData::match_dd_2_index(unordered_map<string, unordered_map<int, unordered_map<int, int> > >& h_dd_p_index, unordered_map<string,
                                 unordered_map<int, unordered_map<int, int> > >& h_dd_n_index, vector<string>& dfs_edge_strings,
                                 unordered_map<string, vector<string> >& dd_path_p_emb, unordered_map<string, vector<string> >& dd_path_n_emb,
                                 unordered_map<string, unordered_map<int, vector<int> > >& ae_dd_match_candidates){
    typedef chrono::high_resolution_clock Clock;
    double t_12 = 0, t_23 = 0, t_34 = 0;

    for (int i = 0; i < dfs_edge_strings.size(); i++){
        auto start_time1 = Clock::now();

        string dfs_edge_string = dfs_edge_strings[i];
        vector<unordered_map<int, unordered_map<int, int> > > path_candidates_p;
        for (int j = 0; j < dd_path_p_emb[dfs_edge_string].size(); j++){
            string unique_emb = dd_path_p_emb[dfs_edge_string][j];
            if (h_dd_p_index.count(unique_emb) != 0){
                path_candidates_p.push_back(h_dd_p_index[unique_emb]);
            }
        }
        auto start_time2 = Clock::now();
        double time_12 = chrono::duration_cast<chrono::nanoseconds>(start_time2 - start_time1).count() / 1e+6;
        t_12 += time_12;

        if (!path_candidates_p.empty()){
            vector<unordered_map<int, unordered_map<int, int> > > path_candidates_n;
            for (int j = 0; j < dd_path_n_emb[dfs_edge_string].size(); j++){
                string unique_emb = dd_path_n_emb[dfs_edge_string][j];
                if (h_dd_n_index.count(unique_emb) != 0){
                    path_candidates_n.push_back(h_dd_n_index[unique_emb]);
                }
            }
            if (!path_candidates_n.empty()){
                unordered_map<int, unordered_map<int, int> >& dfs_edge_candidates_tmp = path_candidates_p[0];
                for (int j = 1; j < path_candidates_p.size(); j++){
                    path_candidate_intersect(dfs_edge_candidates_tmp, path_candidates_p[j]);
                }
                if (!dfs_edge_candidates_tmp.empty()){
                    for (int j = 0; j < path_candidates_n.size(); j++){
                        path_candidate_intersect(dfs_edge_candidates_tmp, path_candidates_n[j]);
                    }

                    if (!dfs_edge_candidates_tmp.empty()){
                        for (const auto& pair : dfs_edge_candidates_tmp){
                            vector<int> dfs_edge_candidate;
                            for (const auto& pair : pair.second){
                                dfs_edge_candidate.push_back(pair.first);
                            }
                        ae_dd_match_candidates[dfs_edge_string][pair.first] = dfs_edge_candidate;
                       }
                    }
                    else{
                        ae_dd_match_candidates[dfs_edge_string] = {};
                    }
                }
                else{
                    ae_dd_match_candidates[dfs_edge_string] = {};
                }
            }
            else{
                ae_dd_match_candidates[dfs_edge_string] = {};
            }
            auto start_time3 = Clock::now();
            double time_23 = chrono::duration_cast<chrono::nanoseconds>(start_time3 - start_time2).count() / 1e+6;
            t_23 += time_23;
        }
        else{
            ae_dd_match_candidates[dfs_edge_string] = {};
        }
    }
}


void MatchData::match_dd_index(unordered_map<string, unordered_map<int, unordered_map<int, int> > >& h_dd_index, vector<string>&
                               dfs_edge_strings, unordered_map<string, vector<string> >& dd_path_emb, unordered_map<string,
                               unordered_map<int, vector<int> > >& ae_dd_match_candidates){
    typedef chrono::high_resolution_clock Clock;
    double t_12 = 0, t_23 = 0, t_34 = 0;

    for (int i = 0; i < dfs_edge_strings.size(); i++){
        auto start_time1 = Clock::now();

        string dfs_edge_string = dfs_edge_strings[i];
        vector<unordered_map<int, unordered_map<int, int> > > path_candidates;
        for (int j = 0; j < dd_path_emb[dfs_edge_string].size(); j++){
            string unique_emb = dd_path_emb[dfs_edge_string][j];
            if (h_dd_index.count(unique_emb) != 0){
                path_candidates.push_back(h_dd_index[unique_emb]);
            }
        }
        auto start_time2 = Clock::now();
        double time_12 = chrono::duration_cast<chrono::nanoseconds>(start_time2 - start_time1).count() / 1e+6;
        t_12 += time_12;

        if (!path_candidates.empty()){
            unordered_map<int, unordered_map<int, int> >& dfs_edge_candidates_tmp = path_candidates[0];
            for (int j = 1; j < path_candidates.size(); j++){
                path_candidate_intersect(dfs_edge_candidates_tmp, path_candidates[j]);
            }

            auto start_time3 = Clock::now();
            double time_23 = chrono::duration_cast<chrono::nanoseconds>(start_time3 - start_time2).count() / 1e+6;
            t_23 += time_23;

            if (!dfs_edge_candidates_tmp.empty()){
                for (const auto& pair : dfs_edge_candidates_tmp){
                    vector<int> dfs_edge_candidate;
                    for (const auto& pair : pair.second){
                        dfs_edge_candidate.push_back(pair.first);
                    }
                    ae_dd_match_candidates[dfs_edge_string][pair.first] = dfs_edge_candidate;
                }
            }
            else{
                ae_dd_match_candidates[dfs_edge_string] = {};
            }
            auto start_time4 = Clock::now();
            double time_34 = chrono::duration_cast<chrono::nanoseconds>(start_time4 - start_time3).count() / 1e+6;
            t_34 += time_34;
        }
        else{
            ae_dd_match_candidates[dfs_edge_string] = {};
        }
    }
}


bool exact_match(vector<int>& forward_positions, vector<int>& current_match, int next_data_node,
                 unordered_map<int, unordered_map<int, int> >& node_neighbors){
    // Check no_dfs_edges
    bool match_flag = true;
	for (int i = 0; i < forward_positions.size(); i++){
		int data_node = current_match[forward_positions[i]];
		if (node_neighbors[next_data_node].count(data_node) == 0){
			match_flag = false;
            break;
		}
	}

	return match_flag;
}


void match_join(string ae_string, int anchor_end_node_position, unordered_map<string, unordered_map<int, vector<int> > >& candidates,
                unordered_map<int, vector<int> >& no_dfs_position, unordered_map<int, unordered_map<int, int> >& node_neighbors,
                MatchResultPtr query_result){
    vector<vector<int> > query_matches_new;
    vector<unordered_map<int, int> > query_matches_dict_new;
    for (int i = 0; i < query_result->query_matches.size(); i++){
        vector<int>& current_match = query_result->query_matches[i];
        unordered_map<int, int>& current_match_dict = query_result->query_matches_dict[i];
        int aen_value = current_match[anchor_end_node_position];
        if (candidates[ae_string].count(aen_value) != 0){
            vector<int>& ae_match_last = candidates[ae_string].at(aen_value);
            for (int j = 0; j < ae_match_last.size(); j++){
                if (current_match_dict.count(ae_match_last[j]) == 0){
                    int next_position = current_match.size();
					if (no_dfs_position.count(next_position) != 0){
						bool match_flag = exact_match(no_dfs_position.at(next_position), current_match, ae_match_last[j], node_neighbors);
						if (match_flag){
                            query_matches_new.push_back(current_match);
                            query_matches_new.back().push_back(ae_match_last[j]);

                            query_matches_dict_new.push_back(current_match_dict);
                            query_matches_dict_new.back()[ae_match_last[j]] = next_position;
						}
					}
					else{
                        query_matches_new.push_back(current_match);
                        query_matches_new.back().push_back(ae_match_last[j]);

                        query_matches_dict_new.push_back(current_match_dict);
                        query_matches_dict_new.back()[ae_match_last[j]] = next_position;
					}
                }
            }
        }
    }
    query_result->query_matches.swap(query_matches_new);
    query_result->query_matches_dict.swap(query_matches_dict_new);
}


void growth_thread(int next_dfs_edge, HashQueryEmbPtr h_query_emb, unordered_map<string, unordered_map<int,
                   vector<int> > >& candidates, unordered_map<int, unordered_map<int, int> >& node_neighbors,
                   MatchResultPtr thread_query_result){
    for (int i = next_dfs_edge; i < h_query_emb->dfs_edge_strings.size(); i++){
        string ae_string = h_query_emb->dfs_edge_strings[i];
        int anchor_end_node = h_query_emb->dfs_edges[i][0];
        int anchor_end_node_position = h_query_emb->query_node_map[anchor_end_node];
        match_join(ae_string, anchor_end_node_position, candidates, h_query_emb->no_dfs_position, node_neighbors, thread_query_result);
    }
}


void MatchData::query_match(HashQueryEmbPtr h_query_emb, unordered_map<string, unordered_map<int, vector<int> > >& candidates, unordered_map<int,
                            unordered_map<int, int> >& node_neighbors, QueryResultPtr query_result, int parallel_threads, MatchResultPtr
                            initial_query_result, unordered_map<int, MatchResultPtr> parallel_query_result, int parallel_query_size){
	typedef chrono::high_resolution_clock Clock;
    auto start_time1 = Clock::now();

	// Initialization
    string initial_ae_string = h_query_emb->dfs_edge_strings[0];
    for (const auto& pair : candidates[initial_ae_string]){
        for (int i = 0; i < pair.second.size(); i++){
            unordered_map<int, int> initial_match_dict = {{pair.first, 0}, {pair.second[i], 1}};
            initial_query_result->query_matches_dict.push_back(initial_match_dict);

            vector<int> initial_match_vec = {pair.first, pair.second[i]};
            initial_query_result->query_matches.push_back(initial_match_vec);
        }
    }

    auto start_time2 = Clock::now();
    double time_12 = chrono::duration_cast<chrono::nanoseconds>(start_time2 - start_time1).count() / 1e+6;

	// Matching results growth
	int next_dfs_edge;
	bool parallel_start = false;
    for (int i = 1; i < h_query_emb->dfs_edge_strings.size(); i++){
        if (initial_query_result->query_matches.size() >= parallel_threads &&
            h_query_emb->dfs_edge_strings.size() > parallel_query_size){
            next_dfs_edge = i;
            parallel_start = true;
            break;
        }
        string ae_string = h_query_emb->dfs_edge_strings[i];
        int anchor_end_node = h_query_emb->dfs_edges[i][0];
        int anchor_end_node_position = h_query_emb->query_node_map[anchor_end_node];
        match_join(ae_string, anchor_end_node_position, candidates, h_query_emb->no_dfs_position, node_neighbors, initial_query_result);
    }

    auto start_time3 = Clock::now();
    double time_23 = chrono::duration_cast<chrono::nanoseconds>(start_time3 - start_time2).count() / 1e+6;

    // Parallel growth
    if (parallel_start){
        omp_set_num_threads(parallel_threads);
        int query_matches_size = initial_query_result->query_matches.size();
        int slice_interval = (query_matches_size + parallel_threads - 1) / parallel_threads;
        #pragma omp parallel for
        for (int i = 0; i < parallel_threads; i++){
            int lower = i * slice_interval;
            int upper = (i + 1) * slice_interval;
            if (upper <= query_matches_size){
                for (int j = lower; j < upper; j++){
                    parallel_query_result[i]->query_matches.push_back(initial_query_result->query_matches[j]);
                    parallel_query_result[i]->query_matches_dict.push_back(initial_query_result->query_matches_dict[j]);
                }
                growth_thread(next_dfs_edge, h_query_emb, candidates, node_neighbors, parallel_query_result[i]);
            }
            else{
                for (int j = lower; j < query_matches_size; j++){
                    parallel_query_result[i]->query_matches.push_back(initial_query_result->query_matches[j]);
                    parallel_query_result[i]->query_matches_dict.push_back(initial_query_result->query_matches_dict[j]);
                }
                growth_thread(next_dfs_edge, h_query_emb, candidates, node_neighbors, parallel_query_result[i]);
            }
        }

      // Output the match results
      for (const auto& pair : parallel_query_result){
            for (int i = 0; i < pair.second->query_matches.size(); i++){
                query_result->query_matches.push_back(pair.second->query_matches[i]);
            }
      }
      for (const auto& pair : parallel_query_result){
            query_result->cardinality += pair.second->query_matches.size();
      }
    }
    else{
        // Output the match results
       query_result->cardinality = initial_query_result->query_matches.size();
       query_result->query_matches.swap(initial_query_result->query_matches);
    }

    auto start_time4 = Clock::now();
    double time_34 = chrono::duration_cast<chrono::nanoseconds>(start_time4 - start_time3).count() / 1e+6;
}


void MatchData::release_result_memory(QueryResultPtr query_result){
    vector<vector<int> >().swap(query_result->query_matches);
    unordered_map<int, int>().swap(query_result->query_node_map);
    unordered_map<string, unordered_map<int, vector<int> > >().swap(query_result->ae_match_candidates);
}

























