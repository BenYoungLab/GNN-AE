#ifndef UTIL_H
#define UTIL_H

#include <set>
#include <vector>
#include <iostream>
#include <algorithm>
#include <unordered_map>

using namespace std;

class Util{
  private:
    Util(){}

  public:
    static void print_format(unordered_map<string, double>& times, int matches_count, unordered_map<string, vector<int> >& dfs_ae_index_hits,
	                          unordered_map<string, unordered_map<int, vector<int> > >& candidates, vector<string>& dfs_edge_strings,
	                          vector<unordered_map<string, unordered_map<int, vector<int> > > >& match_candidates, string dense_index_type);
    static void filtering_power(vector<vector<int> >& query_matches, unordered_map<string, unordered_map<int, vector<int> > >&
                                candidates, vector<int> dfs_nodes, vector<vector<int> >& dfs_edges, int graph_anchor_num);
    static size_t memory_cost_s_index(unordered_map<string, unordered_map<int, vector<int> > >& h_s_index);
    static size_t memory_cost_dd_index(unordered_map<string, unordered_map<int, unordered_map<int, int> > >& h_dd_index);
};

#endif
